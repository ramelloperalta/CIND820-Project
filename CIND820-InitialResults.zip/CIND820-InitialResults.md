# CIND820 Analytics Project
# Controlling a Pandemic: Analyzing Key Factors in COVID-19 Outcomes by Country
Dataset: Our world in COVID-19


```python
%matplotlib inline
import pandas as pd
import numpy as np

#Visualization
#!pip install plotly_express
import plotly_express as px
import matplotlib.pyplot as plt
import seaborn as sns

#Modeling and evaluation
import statsmodels.api as sm
from sklearn.metrics import mean_absolute_error
from sklearn.ensemble import RandomForestRegressor, ExtraTreesClassifier
from sklearn.model_selection import train_test_split
from sklearn.impute import SimpleImputer
```


```python
OWIDdf = pd.read_csv('https://github.com/owid/covid-19-data/raw/master/public/data/owid-covid-data.csv')
```


```python
OWIDdf.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>iso_code</th>
      <th>continent</th>
      <th>location</th>
      <th>date</th>
      <th>total_cases</th>
      <th>new_cases</th>
      <th>new_cases_smoothed</th>
      <th>total_deaths</th>
      <th>new_deaths</th>
      <th>new_deaths_smoothed</th>
      <th>...</th>
      <th>gdp_per_capita</th>
      <th>extreme_poverty</th>
      <th>cardiovasc_death_rate</th>
      <th>diabetes_prevalence</th>
      <th>female_smokers</th>
      <th>male_smokers</th>
      <th>handwashing_facilities</th>
      <th>hospital_beds_per_thousand</th>
      <th>life_expectancy</th>
      <th>human_development_index</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>AFG</td>
      <td>Asia</td>
      <td>Afghanistan</td>
      <td>2020-02-24</td>
      <td>1.0</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>1803.987</td>
      <td>NaN</td>
      <td>597.029</td>
      <td>9.59</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>37.746</td>
      <td>0.5</td>
      <td>64.83</td>
      <td>0.511</td>
    </tr>
    <tr>
      <th>1</th>
      <td>AFG</td>
      <td>Asia</td>
      <td>Afghanistan</td>
      <td>2020-02-25</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>1803.987</td>
      <td>NaN</td>
      <td>597.029</td>
      <td>9.59</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>37.746</td>
      <td>0.5</td>
      <td>64.83</td>
      <td>0.511</td>
    </tr>
    <tr>
      <th>2</th>
      <td>AFG</td>
      <td>Asia</td>
      <td>Afghanistan</td>
      <td>2020-02-26</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>1803.987</td>
      <td>NaN</td>
      <td>597.029</td>
      <td>9.59</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>37.746</td>
      <td>0.5</td>
      <td>64.83</td>
      <td>0.511</td>
    </tr>
    <tr>
      <th>3</th>
      <td>AFG</td>
      <td>Asia</td>
      <td>Afghanistan</td>
      <td>2020-02-27</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>1803.987</td>
      <td>NaN</td>
      <td>597.029</td>
      <td>9.59</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>37.746</td>
      <td>0.5</td>
      <td>64.83</td>
      <td>0.511</td>
    </tr>
    <tr>
      <th>4</th>
      <td>AFG</td>
      <td>Asia</td>
      <td>Afghanistan</td>
      <td>2020-02-28</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>1803.987</td>
      <td>NaN</td>
      <td>597.029</td>
      <td>9.59</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>37.746</td>
      <td>0.5</td>
      <td>64.83</td>
      <td>0.511</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 59 columns</p>
</div>




```python
#The location column contains continent and country values, but we are only interested in countries
OWIDdf = OWIDdf[-OWIDdf.location.isin(['World', 'South America','North America','Asia','Africa','Europe','Australiasia','Antarctica','European Union'])]
```


```python
OWIDdf.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>total_cases</th>
      <th>new_cases</th>
      <th>new_cases_smoothed</th>
      <th>total_deaths</th>
      <th>new_deaths</th>
      <th>new_deaths_smoothed</th>
      <th>total_cases_per_million</th>
      <th>new_cases_per_million</th>
      <th>new_cases_smoothed_per_million</th>
      <th>total_deaths_per_million</th>
      <th>...</th>
      <th>gdp_per_capita</th>
      <th>extreme_poverty</th>
      <th>cardiovasc_death_rate</th>
      <th>diabetes_prevalence</th>
      <th>female_smokers</th>
      <th>male_smokers</th>
      <th>handwashing_facilities</th>
      <th>hospital_beds_per_thousand</th>
      <th>life_expectancy</th>
      <th>human_development_index</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>7.126800e+04</td>
      <td>71263.000000</td>
      <td>70298.000000</td>
      <td>62136.000000</td>
      <td>62194.000000</td>
      <td>70298.000000</td>
      <td>70866.000000</td>
      <td>70861.000000</td>
      <td>69901.000000</td>
      <td>61747.000000</td>
      <td>...</td>
      <td>67776.000000</td>
      <td>46111.000000</td>
      <td>68394.000000</td>
      <td>69276.000000</td>
      <td>53660.000000</td>
      <td>52917.000000</td>
      <td>34124.000000</td>
      <td>62551.000000</td>
      <td>70712.000000</td>
      <td>68337.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>2.500121e+05</td>
      <td>2009.421144</td>
      <td>2012.483992</td>
      <td>7560.426162</td>
      <td>51.944014</td>
      <td>45.520526</td>
      <td>7739.113806</td>
      <td>66.795824</td>
      <td>66.664464</td>
      <td>179.924559</td>
      <td>...</td>
      <td>19174.885330</td>
      <td>13.313368</td>
      <td>257.391972</td>
      <td>7.794138</td>
      <td>10.581282</td>
      <td>32.632604</td>
      <td>50.887803</td>
      <td>3.038005</td>
      <td>73.145857</td>
      <td>0.727781</td>
    </tr>
    <tr>
      <th>std</th>
      <td>1.409119e+06</td>
      <td>11174.505963</td>
      <td>10939.432151</td>
      <td>33380.476616</td>
      <td>244.299506</td>
      <td>217.915320</td>
      <td>15369.787249</td>
      <td>170.648319</td>
      <td>143.290071</td>
      <td>324.915859</td>
      <td>...</td>
      <td>19806.395995</td>
      <td>20.010997</td>
      <td>118.823666</td>
      <td>3.953123</td>
      <td>10.443937</td>
      <td>13.518449</td>
      <td>31.945490</td>
      <td>2.475256</td>
      <td>7.574464</td>
      <td>0.150612</td>
    </tr>
    <tr>
      <th>min</th>
      <td>1.000000e+00</td>
      <td>-74347.000000</td>
      <td>-6223.000000</td>
      <td>1.000000</td>
      <td>-1918.000000</td>
      <td>-232.143000</td>
      <td>0.001000</td>
      <td>-2153.437000</td>
      <td>-276.825000</td>
      <td>0.001000</td>
      <td>...</td>
      <td>661.240000</td>
      <td>0.100000</td>
      <td>79.370000</td>
      <td>0.990000</td>
      <td>0.100000</td>
      <td>7.700000</td>
      <td>1.188000</td>
      <td>0.100000</td>
      <td>53.280000</td>
      <td>0.394000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>7.057500e+02</td>
      <td>1.000000</td>
      <td>5.429000</td>
      <td>35.000000</td>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>146.122500</td>
      <td>0.103000</td>
      <td>0.963000</td>
      <td>5.628000</td>
      <td>...</td>
      <td>4466.507000</td>
      <td>0.500000</td>
      <td>167.295000</td>
      <td>5.290000</td>
      <td>1.900000</td>
      <td>21.400000</td>
      <td>19.351000</td>
      <td>1.300000</td>
      <td>67.440000</td>
      <td>0.602000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>7.259500e+03</td>
      <td>50.000000</td>
      <td>62.000000</td>
      <td>221.500000</td>
      <td>1.000000</td>
      <td>0.857000</td>
      <td>1046.220000</td>
      <td>5.807000</td>
      <td>7.940000</td>
      <td>30.090000</td>
      <td>...</td>
      <td>12951.839000</td>
      <td>2.000000</td>
      <td>242.648000</td>
      <td>7.110000</td>
      <td>6.300000</td>
      <td>31.400000</td>
      <td>49.839000</td>
      <td>2.400000</td>
      <td>74.620000</td>
      <td>0.750000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>7.429250e+04</td>
      <td>563.000000</td>
      <td>587.429000</td>
      <td>1901.000000</td>
      <td>13.000000</td>
      <td>9.857000</td>
      <td>7100.113000</td>
      <td>55.548000</td>
      <td>63.082000</td>
      <td>185.006000</td>
      <td>...</td>
      <td>27216.445000</td>
      <td>21.200000</td>
      <td>329.635000</td>
      <td>10.080000</td>
      <td>19.300000</td>
      <td>41.100000</td>
      <td>83.241000</td>
      <td>4.000000</td>
      <td>78.730000</td>
      <td>0.848000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>2.943878e+07</td>
      <td>300416.000000</td>
      <td>250743.571000</td>
      <td>576013.000000</td>
      <td>5016.000000</td>
      <td>3572.000000</td>
      <td>145809.875000</td>
      <td>8652.658000</td>
      <td>2648.773000</td>
      <td>2268.843000</td>
      <td>...</td>
      <td>116935.600000</td>
      <td>77.600000</td>
      <td>724.417000</td>
      <td>30.530000</td>
      <td>44.000000</td>
      <td>78.100000</td>
      <td>98.999000</td>
      <td>13.800000</td>
      <td>86.750000</td>
      <td>0.957000</td>
    </tr>
  </tbody>
</table>
<p>8 rows × 54 columns</p>
</div>




```python
OWIDdf.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 72412 entries, 0 to 74865
    Data columns (total 59 columns):
     #   Column                                 Non-Null Count  Dtype         
    ---  ------                                 --------------  -----         
     0   iso_code                               72412 non-null  object        
     1   continent                              71169 non-null  object        
     2   location                               72412 non-null  object        
     3   date                                   72412 non-null  datetime64[ns]
     4   total_cases                            71268 non-null  float64       
     5   new_cases                              71263 non-null  float64       
     6   new_cases_smoothed                     70298 non-null  float64       
     7   total_deaths                           62136 non-null  float64       
     8   new_deaths                             62194 non-null  float64       
     9   new_deaths_smoothed                    70298 non-null  float64       
     10  total_cases_per_million                70866 non-null  float64       
     11  new_cases_per_million                  70861 non-null  float64       
     12  new_cases_smoothed_per_million         69901 non-null  float64       
     13  total_deaths_per_million               61747 non-null  float64       
     14  new_deaths_per_million                 61805 non-null  float64       
     15  new_deaths_smoothed_per_million        69901 non-null  float64       
     16  reproduction_rate                      59972 non-null  float64       
     17  icu_patients                           7759 non-null   float64       
     18  icu_patients_per_million               7759 non-null   float64       
     19  hosp_patients                          9337 non-null   float64       
     20  hosp_patients_per_million              9337 non-null   float64       
     21  weekly_icu_admissions                  683 non-null    float64       
     22  weekly_icu_admissions_per_million      683 non-null    float64       
     23  weekly_hosp_admissions                 1261 non-null   float64       
     24  weekly_hosp_admissions_per_million     1261 non-null   float64       
     25  new_tests                              34159 non-null  float64       
     26  total_tests                            33928 non-null  float64       
     27  total_tests_per_thousand               33928 non-null  float64       
     28  new_tests_per_thousand                 34159 non-null  float64       
     29  new_tests_smoothed                     38987 non-null  float64       
     30  new_tests_smoothed_per_thousand        38987 non-null  float64       
     31  positive_rate                          37720 non-null  float64       
     32  tests_per_case                         37141 non-null  float64       
     33  tests_units                            40326 non-null  object        
     34  total_vaccinations                     3871 non-null   float64       
     35  people_vaccinated                      3424 non-null   float64       
     36  people_fully_vaccinated                2262 non-null   float64       
     37  new_vaccinations                       3259 non-null   float64       
     38  new_vaccinations_smoothed              5848 non-null   float64       
     39  total_vaccinations_per_hundred         3871 non-null   float64       
     40  people_vaccinated_per_hundred          3424 non-null   float64       
     41  people_fully_vaccinated_per_hundred    2262 non-null   float64       
     42  new_vaccinations_smoothed_per_million  5848 non-null   float64       
     43  stringency_index                       64056 non-null  float64       
     44  population                             72001 non-null  float64       
     45  population_density                     69522 non-null  float64       
     46  median_age                             67554 non-null  float64       
     47  aged_65_older                          66772 non-null  float64       
     48  aged_70_older                          67171 non-null  float64       
     49  gdp_per_capita                         67776 non-null  float64       
     50  extreme_poverty                        46111 non-null  float64       
     51  cardiovasc_death_rate                  68394 non-null  float64       
     52  diabetes_prevalence                    69276 non-null  float64       
     53  female_smokers                         53660 non-null  float64       
     54  male_smokers                           52917 non-null  float64       
     55  handwashing_facilities                 34124 non-null  float64       
     56  hospital_beds_per_thousand             62551 non-null  float64       
     57  life_expectancy                        70712 non-null  float64       
     58  human_development_index                68337 non-null  float64       
    dtypes: datetime64[ns](1), float64(54), object(4)
    memory usage: 33.1+ MB
    

# Data Preprocessing


```python
OWIDdf.isnull().sum()
```




    iso_code                                     0
    continent                                 3697
    location                                     0
    date                                         0
    total_cases                               1147
    new_cases                                 1149
    new_cases_smoothed                        2150
    total_deaths                             10376
    new_deaths                               10218
    new_deaths_smoothed                       2150
    total_cases_per_million                   1549
    new_cases_per_million                     1551
    new_cases_smoothed_per_million            2547
    total_deaths_per_million                 10765
    new_deaths_per_million                   10607
    new_deaths_smoothed_per_million           2547
    reproduction_rate                        14478
    icu_patients                             67107
    icu_patients_per_million                 67107
    hosp_patients                            65529
    hosp_patients_per_million                65529
    weekly_icu_admissions                    74183
    weekly_icu_admissions_per_million        74183
    weekly_hosp_admissions                   73605
    weekly_hosp_admissions_per_million       73605
    new_tests                                40707
    total_tests                              40938
    total_tests_per_thousand                 40938
    new_tests_per_thousand                   40707
    new_tests_smoothed                       35879
    new_tests_smoothed_per_thousand          35879
    positive_rate                            37146
    tests_per_case                           37725
    tests_units                              34540
    total_vaccinations                       70903
    people_vaccinated                        71350
    people_fully_vaccinated                  72533
    new_vaccinations                         71516
    new_vaccinations_smoothed                68927
    total_vaccinations_per_hundred           70903
    people_vaccinated_per_hundred            71350
    people_fully_vaccinated_per_hundred      72533
    new_vaccinations_smoothed_per_million    68927
    stringency_index                         10810
    population                                 411
    population_density                        4926
    median_age                                6894
    aged_65_older                             7676
    aged_70_older                             7277
    gdp_per_capita                            6672
    extreme_poverty                          28337
    cardiovasc_death_rate                     6054
    diabetes_prevalence                       5172
    female_smokers                           20788
    male_smokers                             21531
    handwashing_facilities                   40324
    hospital_beds_per_thousand               11897
    life_expectancy                           3736
    human_development_index                   6111
    dtype: int64




```python
###Removing columns where na is more than 50000

owiddfn = OWIDdf.loc[:, OWIDdf.isna().sum() < 50000]
```


```python
###new_test features removed as they will correlate with total_test

owiddfn = owiddfn[owiddfn.columns.difference(owiddfn.filter(like='new').columns,sort=False)]
```


```python
###Removing redundant columns/ with high correlation
owiddfn = owiddfn.drop(columns=['total_cases','total_deaths','total_tests','aged_65_older','aged_70_older','iso_code','continent'])
```


    ---------------------------------------------------------------------------

    KeyError                                  Traceback (most recent call last)

    <ipython-input-173-2a9271070910> in <module>
          1 ###Removing redundant columns/ with high correlation
    ----> 2 owiddfn = owiddfn.drop(columns=['total_cases','total_deaths','total_tests','aged_65_older','aged_70_older','iso_code','continent'])
    

    ~\anaconda3\lib\site-packages\pandas\core\frame.py in drop(self, labels, axis, index, columns, level, inplace, errors)
       3995             level=level,
       3996             inplace=inplace,
    -> 3997             errors=errors,
       3998         )
       3999 
    

    ~\anaconda3\lib\site-packages\pandas\core\generic.py in drop(self, labels, axis, index, columns, level, inplace, errors)
       3934         for axis, labels in axes.items():
       3935             if labels is not None:
    -> 3936                 obj = obj._drop_axis(labels, axis, level=level, errors=errors)
       3937 
       3938         if inplace:
    

    ~\anaconda3\lib\site-packages\pandas\core\generic.py in _drop_axis(self, labels, axis, level, errors)
       3968                 new_axis = axis.drop(labels, level=level, errors=errors)
       3969             else:
    -> 3970                 new_axis = axis.drop(labels, errors=errors)
       3971             result = self.reindex(**{axis_name: new_axis})
       3972 
    

    ~\anaconda3\lib\site-packages\pandas\core\indexes\base.py in drop(self, labels, errors)
       5016         if mask.any():
       5017             if errors != "ignore":
    -> 5018                 raise KeyError(f"{labels[mask]} not found in axis")
       5019             indexer = indexer[~mask]
       5020         return self.delete(indexer)
    

    KeyError: "['total_cases' 'total_deaths' 'total_tests' 'aged_65_older'\n 'aged_70_older' 'iso_code' 'continent'] not found in axis"



```python
owiddfn.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 72412 entries, 0 to 74865
    Data columns (total 23 columns):
     #   Column                      Non-Null Count  Dtype         
    ---  ------                      --------------  -----         
     0   location                    72412 non-null  object        
     1   date                        72412 non-null  datetime64[ns]
     2   total_cases_per_million     70866 non-null  float64       
     3   total_deaths_per_million    61747 non-null  float64       
     4   reproduction_rate           59972 non-null  float64       
     5   total_tests_per_thousand    33928 non-null  float64       
     6   positive_rate               37720 non-null  float64       
     7   tests_per_case              37141 non-null  float64       
     8   tests_units                 40326 non-null  object        
     9   stringency_index            64056 non-null  float64       
     10  population                  72001 non-null  float64       
     11  population_density          69522 non-null  float64       
     12  median_age                  67554 non-null  float64       
     13  gdp_per_capita              67776 non-null  float64       
     14  extreme_poverty             46111 non-null  float64       
     15  cardiovasc_death_rate       68394 non-null  float64       
     16  diabetes_prevalence         69276 non-null  float64       
     17  female_smokers              53660 non-null  float64       
     18  male_smokers                52917 non-null  float64       
     19  handwashing_facilities      34124 non-null  float64       
     20  hospital_beds_per_thousand  62551 non-null  float64       
     21  life_expectancy             70712 non-null  float64       
     22  human_development_index     68337 non-null  float64       
    dtypes: datetime64[ns](1), float64(20), object(2)
    memory usage: 13.3+ MB
    

In the earlier stages of the pandemic, there was a lot of missing or underreported information.


```python
odf = owiddfn.copy()


#Removing rows from Jan 2020 as there was a lot of underreported data
odf.date = pd.to_datetime(odf.date)
earliest_date = odf.date.min()
odf = odf.loc['2020-02-01':] #February 2020 and beyond
odf.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 53026 entries, 20200 to 74865
    Data columns (total 23 columns):
     #   Column                      Non-Null Count  Dtype         
    ---  ------                      --------------  -----         
     0   location                    53026 non-null  object        
     1   date                        53026 non-null  datetime64[ns]
     2   total_cases_per_million     51749 non-null  float64       
     3   total_deaths_per_million    44591 non-null  float64       
     4   reproduction_rate           43179 non-null  float64       
     5   total_tests_per_thousand    26328 non-null  float64       
     6   positive_rate               29204 non-null  float64       
     7   tests_per_case              28656 non-null  float64       
     8   tests_units                 30921 non-null  object        
     9   stringency_index            46104 non-null  float64       
     10  population                  52615 non-null  float64       
     11  population_density          50159 non-null  float64       
     12  median_age                  49064 non-null  float64       
     13  gdp_per_capita              49159 non-null  float64       
     14  extreme_poverty             33943 non-null  float64       
     15  cardiovasc_death_rate       49108 non-null  float64       
     16  diabetes_prevalence         49913 non-null  float64       
     17  female_smokers              39191 non-null  float64       
     18  male_smokers                38448 non-null  float64       
     19  handwashing_facilities      24118 non-null  float64       
     20  hospital_beds_per_thousand  45527 non-null  float64       
     21  life_expectancy             51326 non-null  float64       
     22  human_development_index     49111 non-null  float64       
    dtypes: datetime64[ns](1), float64(20), object(2)
    memory usage: 9.7+ MB
    


```python
odf.isnull().sum(axis = 1).plot(kind='hist')
```




    <matplotlib.axes._subplots.AxesSubplot at 0x138d7b35f08>




![png](output_15_1.png)



```python
#Remove rows with 5+ NAs
odf = odf[odf.isnull().sum(axis=1) < 5]
```


```python
#Removing NA from dependent variables

odf = odf[odf['total_cases_per_million'].notna()]
odf = odf[odf['total_deaths_per_million'].notna()]
odf = odf[odf['reproduction_rate'].notna()]
```


```python
odf.isnull().sum(axis = 1).plot(kind='hist')
```




    <matplotlib.axes._subplots.AxesSubplot at 0x138d71b5ac8>




![png](output_18_1.png)



```python
odf.info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 29483 entries, 20218 to 74863
    Data columns (total 23 columns):
     #   Column                      Non-Null Count  Dtype         
    ---  ------                      --------------  -----         
     0   location                    29483 non-null  object        
     1   date                        29483 non-null  datetime64[ns]
     2   total_cases_per_million     29483 non-null  float64       
     3   total_deaths_per_million    29483 non-null  float64       
     4   reproduction_rate           29483 non-null  float64       
     5   total_tests_per_thousand    23689 non-null  float64       
     6   positive_rate               26294 non-null  float64       
     7   tests_per_case              26206 non-null  float64       
     8   tests_units                 26445 non-null  object        
     9   stringency_index            28528 non-null  float64       
     10  population                  29483 non-null  float64       
     11  population_density          29483 non-null  float64       
     12  median_age                  29483 non-null  float64       
     13  gdp_per_capita              29483 non-null  float64       
     14  extreme_poverty             23175 non-null  float64       
     15  cardiovasc_death_rate       29483 non-null  float64       
     16  diabetes_prevalence         29483 non-null  float64       
     17  female_smokers              27488 non-null  float64       
     18  male_smokers                27152 non-null  float64       
     19  handwashing_facilities      14231 non-null  float64       
     20  hospital_beds_per_thousand  27704 non-null  float64       
     21  life_expectancy             29483 non-null  float64       
     22  human_development_index     29483 non-null  float64       
    dtypes: datetime64[ns](1), float64(20), object(2)
    memory usage: 5.4+ MB
    


```python
'''
np.unique(odf.location)
country_subset = ['Canada','United States','Vietnam','United Kingdom','Uganda','Thailand','Indonesia','Italy',
                  'Jamaica','Japan','Philippines','Poland','Ghana','Greece','Colombia','China',
                 'Brazil','South Korea','New Zealand','Russia','Libya','Botswana']'''
```




    "\nnp.unique(odf.location)\ncountry_subset = ['Canada','United States','Vietnam','United Kingdom','Uganda','Thailand','Indonesia','Italy',\n                  'Jamaica','Japan','Philippines','Poland','Ghana','Greece','Colombia','China',\n                 'Brazil','South Korea','New Zealand','Russia','Libya','Botswana']"



# Imbalanced Target Data 

Much of the target variables have sparse data or are heavily imbalanced and must be further processed to yield more realistic results. SMOGN will later be used to solve this problem


```python
#Total_cases_per_million
#Imbalanced data?
odf.total_cases_per_million.plot(kind='hist')
```




    <matplotlib.axes._subplots.AxesSubplot at 0x138d811d408>




![png](output_23_1.png)



```python
odf[odf.total_cases_per_million < 10000].info()
```

    <class 'pandas.core.frame.DataFrame'>
    Int64Index: 22286 entries, 20218 to 74863
    Data columns (total 23 columns):
     #   Column                      Non-Null Count  Dtype         
    ---  ------                      --------------  -----         
     0   location                    22286 non-null  object        
     1   date                        22286 non-null  datetime64[ns]
     2   total_cases_per_million     22286 non-null  float64       
     3   total_deaths_per_million    22286 non-null  float64       
     4   reproduction_rate           22286 non-null  float64       
     5   total_tests_per_thousand    17621 non-null  float64       
     6   positive_rate               19496 non-null  float64       
     7   tests_per_case              19408 non-null  float64       
     8   tests_units                 19630 non-null  object        
     9   stringency_index            21853 non-null  float64       
     10  population                  22286 non-null  float64       
     11  population_density          22286 non-null  float64       
     12  median_age                  22286 non-null  float64       
     13  gdp_per_capita              22286 non-null  float64       
     14  extreme_poverty             17903 non-null  float64       
     15  cardiovasc_death_rate       22286 non-null  float64       
     16  diabetes_prevalence         22286 non-null  float64       
     17  female_smokers              20730 non-null  float64       
     18  male_smokers                20615 non-null  float64       
     19  handwashing_facilities      12757 non-null  float64       
     20  hospital_beds_per_thousand  20788 non-null  float64       
     21  life_expectancy             22286 non-null  float64       
     22  human_development_index     22286 non-null  float64       
    dtypes: datetime64[ns](1), float64(20), object(2)
    memory usage: 4.1+ MB
    


```python
#total_deaths_per_million
#Imbalanced
odf.total_deaths_per_million.plot(kind='hist')
```




    <matplotlib.axes._subplots.AxesSubplot at 0x138d8267bc8>




![png](output_25_1.png)



```python
#Looking at the distribution of reproduction_rate
odf.reproduction_rate.plot(kind ='hist')
print(odf.reproduction_rate.max())
```

    6.73
    


![png](output_26_1.png)


# Exploratory Data Analysis 


```python
odf.corr()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>total_cases_per_million</th>
      <th>total_deaths_per_million</th>
      <th>reproduction_rate</th>
      <th>total_tests_per_thousand</th>
      <th>positive_rate</th>
      <th>tests_per_case</th>
      <th>stringency_index</th>
      <th>population</th>
      <th>population_density</th>
      <th>median_age</th>
      <th>gdp_per_capita</th>
      <th>extreme_poverty</th>
      <th>cardiovasc_death_rate</th>
      <th>diabetes_prevalence</th>
      <th>female_smokers</th>
      <th>male_smokers</th>
      <th>handwashing_facilities</th>
      <th>hospital_beds_per_thousand</th>
      <th>life_expectancy</th>
      <th>human_development_index</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>total_cases_per_million</th>
      <td>1.000000</td>
      <td>0.794825</td>
      <td>-0.101335</td>
      <td>0.623425</td>
      <td>0.158689</td>
      <td>-0.086187</td>
      <td>0.099879</td>
      <td>-0.069360</td>
      <td>0.031807</td>
      <td>0.290051</td>
      <td>0.331688</td>
      <td>-0.280246</td>
      <td>-0.159827</td>
      <td>0.153326</td>
      <td>0.269350</td>
      <td>0.044937</td>
      <td>0.344480</td>
      <td>0.133104</td>
      <td>0.317444</td>
      <td>0.343915</td>
    </tr>
    <tr>
      <th>total_deaths_per_million</th>
      <td>0.794825</td>
      <td>1.000000</td>
      <td>-0.076497</td>
      <td>0.329876</td>
      <td>0.228323</td>
      <td>-0.094805</td>
      <td>0.123192</td>
      <td>-0.036077</td>
      <td>-0.075208</td>
      <td>0.324160</td>
      <td>0.167548</td>
      <td>-0.293471</td>
      <td>-0.192784</td>
      <td>-0.003515</td>
      <td>0.362206</td>
      <td>-0.012498</td>
      <td>0.291408</td>
      <td>0.130680</td>
      <td>0.313143</td>
      <td>0.330230</td>
    </tr>
    <tr>
      <th>reproduction_rate</th>
      <td>-0.101335</td>
      <td>-0.076497</td>
      <td>1.000000</td>
      <td>-0.072971</td>
      <td>0.083477</td>
      <td>-0.120327</td>
      <td>0.076986</td>
      <td>0.039879</td>
      <td>-0.023945</td>
      <td>0.112796</td>
      <td>0.051210</td>
      <td>-0.162871</td>
      <td>-0.007587</td>
      <td>0.051590</td>
      <td>0.084565</td>
      <td>0.056677</td>
      <td>0.082909</td>
      <td>0.086086</td>
      <td>0.092543</td>
      <td>0.115055</td>
    </tr>
    <tr>
      <th>total_tests_per_thousand</th>
      <td>0.623425</td>
      <td>0.329876</td>
      <td>-0.072971</td>
      <td>1.000000</td>
      <td>-0.163887</td>
      <td>0.033120</td>
      <td>-0.077109</td>
      <td>-0.080341</td>
      <td>0.150147</td>
      <td>0.244812</td>
      <td>0.441332</td>
      <td>-0.211995</td>
      <td>-0.140232</td>
      <td>0.127244</td>
      <td>0.194745</td>
      <td>0.024765</td>
      <td>0.331128</td>
      <td>0.067400</td>
      <td>0.298394</td>
      <td>0.350057</td>
    </tr>
    <tr>
      <th>positive_rate</th>
      <td>0.158689</td>
      <td>0.228323</td>
      <td>0.083477</td>
      <td>-0.163887</td>
      <td>1.000000</td>
      <td>-0.161491</td>
      <td>0.250842</td>
      <td>-0.003923</td>
      <td>-0.105812</td>
      <td>-0.171525</td>
      <td>-0.226244</td>
      <td>-0.003307</td>
      <td>0.073802</td>
      <td>0.067325</td>
      <td>-0.091870</td>
      <td>-0.057389</td>
      <td>0.122732</td>
      <td>-0.152493</td>
      <td>-0.122177</td>
      <td>-0.146110</td>
    </tr>
    <tr>
      <th>tests_per_case</th>
      <td>-0.086187</td>
      <td>-0.094805</td>
      <td>-0.120327</td>
      <td>0.033120</td>
      <td>-0.161491</td>
      <td>1.000000</td>
      <td>-0.089627</td>
      <td>-0.032690</td>
      <td>0.142384</td>
      <td>0.068932</td>
      <td>0.095143</td>
      <td>-0.061070</td>
      <td>-0.100073</td>
      <td>0.004848</td>
      <td>-0.007663</td>
      <td>-0.057381</td>
      <td>0.072467</td>
      <td>-0.009809</td>
      <td>0.111401</td>
      <td>0.100968</td>
    </tr>
    <tr>
      <th>stringency_index</th>
      <td>0.099879</td>
      <td>0.123192</td>
      <td>0.076986</td>
      <td>-0.077109</td>
      <td>0.250842</td>
      <td>-0.089627</td>
      <td>1.000000</td>
      <td>0.103059</td>
      <td>-0.013693</td>
      <td>0.010507</td>
      <td>0.010800</td>
      <td>-0.260107</td>
      <td>-0.105074</td>
      <td>0.212762</td>
      <td>-0.050952</td>
      <td>0.039911</td>
      <td>0.328996</td>
      <td>-0.168836</td>
      <td>0.129374</td>
      <td>0.102964</td>
    </tr>
    <tr>
      <th>population</th>
      <td>-0.069360</td>
      <td>-0.036077</td>
      <td>0.039879</td>
      <td>-0.080341</td>
      <td>-0.003923</td>
      <td>-0.032690</td>
      <td>0.103059</td>
      <td>1.000000</td>
      <td>0.008923</td>
      <td>-0.092640</td>
      <td>-0.109647</td>
      <td>0.042404</td>
      <td>0.067096</td>
      <td>0.101404</td>
      <td>-0.145468</td>
      <td>-0.032658</td>
      <td>0.018974</td>
      <td>-0.122825</td>
      <td>-0.128548</td>
      <td>-0.118254</td>
    </tr>
    <tr>
      <th>population_density</th>
      <td>0.031807</td>
      <td>-0.075208</td>
      <td>-0.023945</td>
      <td>0.150147</td>
      <td>-0.105812</td>
      <td>0.142384</td>
      <td>-0.013693</td>
      <td>0.008923</td>
      <td>1.000000</td>
      <td>0.103564</td>
      <td>0.282438</td>
      <td>-0.018574</td>
      <td>-0.164650</td>
      <td>0.180467</td>
      <td>-0.094590</td>
      <td>0.019728</td>
      <td>0.056276</td>
      <td>-0.027360</td>
      <td>0.155050</td>
      <td>0.120175</td>
    </tr>
    <tr>
      <th>median_age</th>
      <td>0.290051</td>
      <td>0.324160</td>
      <td>0.112796</td>
      <td>0.244812</td>
      <td>-0.171525</td>
      <td>0.068932</td>
      <td>0.010507</td>
      <td>-0.092640</td>
      <td>0.103564</td>
      <td>1.000000</td>
      <td>0.585727</td>
      <td>-0.699459</td>
      <td>-0.237923</td>
      <td>0.175786</td>
      <td>0.738205</td>
      <td>0.324175</td>
      <td>0.779848</td>
      <td>0.699065</td>
      <td>0.843588</td>
      <td>0.884053</td>
    </tr>
    <tr>
      <th>gdp_per_capita</th>
      <td>0.331688</td>
      <td>0.167548</td>
      <td>0.051210</td>
      <td>0.441332</td>
      <td>-0.226244</td>
      <td>0.095143</td>
      <td>0.010800</td>
      <td>-0.109647</td>
      <td>0.282438</td>
      <td>0.585727</td>
      <td>1.000000</td>
      <td>-0.496418</td>
      <td>-0.449810</td>
      <td>0.327089</td>
      <td>0.359265</td>
      <td>-0.042955</td>
      <td>0.724620</td>
      <td>0.258863</td>
      <td>0.678980</td>
      <td>0.741158</td>
    </tr>
    <tr>
      <th>extreme_poverty</th>
      <td>-0.280246</td>
      <td>-0.293471</td>
      <td>-0.162871</td>
      <td>-0.211995</td>
      <td>-0.003307</td>
      <td>-0.061070</td>
      <td>-0.260107</td>
      <td>0.042404</td>
      <td>-0.018574</td>
      <td>-0.699459</td>
      <td>-0.496418</td>
      <td>1.000000</td>
      <td>0.137917</td>
      <td>-0.429065</td>
      <td>-0.421376</td>
      <td>-0.352119</td>
      <td>-0.762730</td>
      <td>-0.446169</td>
      <td>-0.735949</td>
      <td>-0.763864</td>
    </tr>
    <tr>
      <th>cardiovasc_death_rate</th>
      <td>-0.159827</td>
      <td>-0.192784</td>
      <td>-0.007587</td>
      <td>-0.140232</td>
      <td>0.073802</td>
      <td>-0.100073</td>
      <td>-0.105074</td>
      <td>0.067096</td>
      <td>-0.164650</td>
      <td>-0.237923</td>
      <td>-0.449810</td>
      <td>0.137917</td>
      <td>1.000000</td>
      <td>0.029161</td>
      <td>-0.145156</td>
      <td>0.443353</td>
      <td>0.086573</td>
      <td>0.061026</td>
      <td>-0.473141</td>
      <td>-0.401045</td>
    </tr>
    <tr>
      <th>diabetes_prevalence</th>
      <td>0.153326</td>
      <td>-0.003515</td>
      <td>0.051590</td>
      <td>0.127244</td>
      <td>0.067325</td>
      <td>0.004848</td>
      <td>0.212762</td>
      <td>0.101404</td>
      <td>0.180467</td>
      <td>0.175786</td>
      <td>0.327089</td>
      <td>-0.429065</td>
      <td>0.029161</td>
      <td>1.000000</td>
      <td>-0.137536</td>
      <td>0.211309</td>
      <td>0.681668</td>
      <td>-0.113323</td>
      <td>0.323646</td>
      <td>0.300132</td>
    </tr>
    <tr>
      <th>female_smokers</th>
      <td>0.269350</td>
      <td>0.362206</td>
      <td>0.084565</td>
      <td>0.194745</td>
      <td>-0.091870</td>
      <td>-0.007663</td>
      <td>-0.050952</td>
      <td>-0.145468</td>
      <td>-0.094590</td>
      <td>0.738205</td>
      <td>0.359265</td>
      <td>-0.421376</td>
      <td>-0.145156</td>
      <td>-0.137536</td>
      <td>1.000000</td>
      <td>0.219192</td>
      <td>0.369223</td>
      <td>0.517463</td>
      <td>0.542940</td>
      <td>0.618790</td>
    </tr>
    <tr>
      <th>male_smokers</th>
      <td>0.044937</td>
      <td>-0.012498</td>
      <td>0.056677</td>
      <td>0.024765</td>
      <td>-0.057389</td>
      <td>-0.057381</td>
      <td>0.039911</td>
      <td>-0.032658</td>
      <td>0.019728</td>
      <td>0.324175</td>
      <td>-0.042955</td>
      <td>-0.352119</td>
      <td>0.443353</td>
      <td>0.211309</td>
      <td>0.219192</td>
      <td>1.000000</td>
      <td>0.527559</td>
      <td>0.363589</td>
      <td>0.174907</td>
      <td>0.187179</td>
    </tr>
    <tr>
      <th>handwashing_facilities</th>
      <td>0.344480</td>
      <td>0.291408</td>
      <td>0.082909</td>
      <td>0.331128</td>
      <td>0.122732</td>
      <td>0.072467</td>
      <td>0.328996</td>
      <td>0.018974</td>
      <td>0.056276</td>
      <td>0.779848</td>
      <td>0.724620</td>
      <td>-0.762730</td>
      <td>0.086573</td>
      <td>0.681668</td>
      <td>0.369223</td>
      <td>0.527559</td>
      <td>1.000000</td>
      <td>0.569663</td>
      <td>0.791337</td>
      <td>0.847236</td>
    </tr>
    <tr>
      <th>hospital_beds_per_thousand</th>
      <td>0.133104</td>
      <td>0.130680</td>
      <td>0.086086</td>
      <td>0.067400</td>
      <td>-0.152493</td>
      <td>-0.009809</td>
      <td>-0.168836</td>
      <td>-0.122825</td>
      <td>-0.027360</td>
      <td>0.699065</td>
      <td>0.258863</td>
      <td>-0.446169</td>
      <td>0.061026</td>
      <td>-0.113323</td>
      <td>0.517463</td>
      <td>0.363589</td>
      <td>0.569663</td>
      <td>1.000000</td>
      <td>0.451308</td>
      <td>0.551163</td>
    </tr>
    <tr>
      <th>life_expectancy</th>
      <td>0.317444</td>
      <td>0.313143</td>
      <td>0.092543</td>
      <td>0.298394</td>
      <td>-0.122177</td>
      <td>0.111401</td>
      <td>0.129374</td>
      <td>-0.128548</td>
      <td>0.155050</td>
      <td>0.843588</td>
      <td>0.678980</td>
      <td>-0.735949</td>
      <td>-0.473141</td>
      <td>0.323646</td>
      <td>0.542940</td>
      <td>0.174907</td>
      <td>0.791337</td>
      <td>0.451308</td>
      <td>1.000000</td>
      <td>0.920129</td>
    </tr>
    <tr>
      <th>human_development_index</th>
      <td>0.343915</td>
      <td>0.330230</td>
      <td>0.115055</td>
      <td>0.350057</td>
      <td>-0.146110</td>
      <td>0.100968</td>
      <td>0.102964</td>
      <td>-0.118254</td>
      <td>0.120175</td>
      <td>0.884053</td>
      <td>0.741158</td>
      <td>-0.763864</td>
      <td>-0.401045</td>
      <td>0.300132</td>
      <td>0.618790</td>
      <td>0.187179</td>
      <td>0.847236</td>
      <td>0.551163</td>
      <td>0.920129</td>
      <td>1.000000</td>
    </tr>
  </tbody>
</table>
</div>




```python
hmp = sns.heatmap(odf.corr())
hmp.set_title('OWID COVID Correlation Heatmap')
```




    Text(0.5, 1, 'OWID COVID Correlation Heatmap')




![png](output_29_1.png)



```python
dhmp = sns.heatmap(odf.corr()[['total_cases_per_million']].sort_values(by='total_cases_per_million', ascending=False), annot=True, cmap='BrBG')
dhmp.set_title('Features correlating with total_cases')
```




    Text(0.5, 1, 'Features correlating with total_cases')




![png](output_30_1.png)



```python
dhmp = sns.heatmap(odf.corr()[['total_deaths_per_million']].sort_values(by='total_deaths_per_million', ascending=False), annot=True, cmap='BrBG')
dhmp.set_title('Features correlating with total_deaths')
```




    Text(0.5, 1, 'Features correlating with total_deaths')




![png](output_31_1.png)



```python
nowiddfn = odf.select_dtypes(include='float64')
#ppdf = sns.pairplot(nowiddfn.sample(1000))
#ppdf.savefig("pairplotowid.png")
```

Some of the target variables to consider: reproduction_rate, total_cases_per_million, total_deaths_per_million.
Normally we would also consider crude mortality rate or case-fatality rate as well. However, confirmed cases is often underreported AND undertested and as such may be harder to evaluate accurately. It is important to consider that the data being robust and accurate relies heavily on the nation's testing capacity. 

Remember that the reproduction rate (R) describes the trajectory of the virus. A value of R = 1 means the amount of new infections and new recoveries are equal; meaning the virus numbers will stagnate. A value of 6.74 means the number of infected is sharply increasing and may lead in a big spike of infections and deaths, depending on government mitigation strategy.


```python
print(OWIDdf.reproduction_rate.max())
odf[odf.reproduction_rate==OWIDdf.reproduction_rate.max()]
```

    6.72
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>location</th>
      <th>date</th>
      <th>total_cases_per_million</th>
      <th>total_deaths_per_million</th>
      <th>reproduction_rate</th>
      <th>total_tests_per_thousand</th>
      <th>positive_rate</th>
      <th>tests_per_case</th>
      <th>tests_units</th>
      <th>stringency_index</th>
      <th>...</th>
      <th>gdp_per_capita</th>
      <th>extreme_poverty</th>
      <th>cardiovasc_death_rate</th>
      <th>diabetes_prevalence</th>
      <th>female_smokers</th>
      <th>male_smokers</th>
      <th>handwashing_facilities</th>
      <th>hospital_beds_per_thousand</th>
      <th>life_expectancy</th>
      <th>human_development_index</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>61437</th>
      <td>South Korea</td>
      <td>2020-02-22</td>
      <td>8.446</td>
      <td>0.039</td>
      <td>6.72</td>
      <td>0.383</td>
      <td>0.033</td>
      <td>29.9</td>
      <td>people tested</td>
      <td>45.37</td>
      <td>...</td>
      <td>35938.374</td>
      <td>0.2</td>
      <td>85.998</td>
      <td>6.8</td>
      <td>6.2</td>
      <td>40.9</td>
      <td>NaN</td>
      <td>12.27</td>
      <td>83.03</td>
      <td>0.916</td>
    </tr>
  </tbody>
</table>
<p>1 rows × 23 columns</p>
</div>



# Calculating Crude Mortality/Case-Fatality


```python
odfdt.date.max()
```




    Timestamp('2021-03-13 00:00:00')




```python
#Most recent data
odfdt = OWIDdf.copy()
odfdt['date'] = pd.to_datetime(odfdt['date'])
most_recent_date = odf.date.max();

odfdt = odfdt[odfdt.date == most_recent_date]
```


```python
OWIDdf.date = pd.to_datetime(OWIDdf.date)
```


```python
#Calculating Crude Mortality (COVID deaths/population) and CaseFatality (COVID deaths/COVID cases)
SK_Covid_Crude_Mortality = (OWIDdf[(OWIDdf.location == 'South Korea') & (OWIDdf.date == most_recent_date)].total_deaths) / (OWIDdf[(OWIDdf.location == 'South Korea') & (OWIDdf.date == most_recent_date)].population)
SK_Covid_CaseFatality = (OWIDdf[(OWIDdf.location == 'South Korea') & (OWIDdf.date == most_recent_date)].total_deaths) / (OWIDdf[(OWIDdf.location == 'South Korea') & (OWIDdf.date == most_recent_date)].total_cases)

SK_Median_age = OWIDdf[(OWIDdf.location == 'South Korea') & (OWIDdf.date == most_recent_date)].median_age.iloc[0]
print(" South Korea Crude Mortality:",SK_Covid_Crude_Mortality.iloc[0],"%\n","South Korea Case-Fatality: ",SK_Covid_CaseFatality.iloc[0],"%\n", "Median Age:", SK_Median_age)
```

     South Korea Crude Mortality: 3.267069810728211e-05 %
     South Korea Case-Fatality:  0.017444827478467356 %
     Median Age: 43.4
    

South Korea reported one of the largest spikes in the early stages of the pandemic, yet they are one of the countries with the lowest COVID-19 Mortality, which may be attributed to hospital bed capacity.


```python
ITA_Covid_Crude_Mortality = (OWIDdf[(OWIDdf.location == 'Italy') & (OWIDdf.date == most_recent_date)].total_deaths) / (OWIDdf[(OWIDdf.location == 'Italy') & (OWIDdf.date == most_recent_date)].population)
ITA_Covid_CaseFatality = (OWIDdf[(OWIDdf.location == 'Italy') & (OWIDdf.date == most_recent_date)].total_deaths) / (OWIDdf[(OWIDdf.location == 'Italy') & (OWIDdf.date == most_recent_date)].total_cases)

ITA_Median_age = OWIDdf[(OWIDdf.location == 'Italy') & (OWIDdf.date == most_recent_date)].median_age.iloc[0]
print(" Italy Crude Mortality:",ITA_Covid_Crude_Mortality.iloc[0],"%\n","Italy Case-Fatality: ",ITA_Covid_CaseFatality.iloc[0],"%\n", "Median Age:", ITA_Median_age )
```

     Italy Crude Mortality: 0.0016850466380209344 %
     Italy Case-Fatality:  0.03181953615392159 %
     Median Age: 47.9
    

Italy may have suffered more loss due to their higher median age.



```python
US_Covid_Crude_Mortality = (OWIDdf[(OWIDdf.location == 'United States') & (OWIDdf.date == most_recent_date)].total_deaths) / (OWIDdf[(OWIDdf.location == 'United States') & (OWIDdf.date == most_recent_date)].population)
US_Covid_CaseFatality = (OWIDdf[(OWIDdf.location == 'United States') & (OWIDdf.date == most_recent_date)].total_deaths) / (OWIDdf[(OWIDdf.location == 'United States') & (OWIDdf.date == most_recent_date)].total_cases)

US_Median_age = OWIDdf[(OWIDdf.location == 'United States') & (OWIDdf.date == most_recent_date)].median_age.iloc[0]
print(" United States Crude Mortality:",US_Covid_Crude_Mortality.iloc[0],"%\n","United States Case-Fatality: ",US_Covid_CaseFatality.iloc[0],"%\n", "Median Age:", US_Median_age )
```

     United States Crude Mortality: 0.0016142348251372142 %
     United States Case-Fatality:  0.01817367176733036 %
     Median Age: 38.3
    

Crude Mortality or Case fatality may be used a generated target feature.

# Visualizations

A look into total cases by location. Note that total cases cannot alone represent a good target variable as an absolute value hence a relative value total_cases_per_million is used


```python
countries = odfdt.groupby('location')['total_cases'].sum()

countries_per = countries.groupby('location').agg(percentage =('total_cases', lambda p: p.sum() / countries.sum() * 100)).round(2)

sns.set_style("whitegrid")
bar, ax = plt.subplots(figsize=(11,100))
ax = sns.barplot(x="percentage",y=countries_per.index, data=countries_per, ci=None, palette='muted', orient = 'h')
ax.set_title("Relative frequency graph of Total cases worldwide")
```




    Text(0.5, 1.0, 'Relative frequency graph of Total cases worldwide')




![png](output_48_1.png)



```python
plt.pie(countries)
plt.show()
```


![png](output_49_0.png)



```python
countries = odfdt.groupby('location')['total_cases_per_million'].sum()
countries_per = countries.groupby('location').agg(percentage =('total_cases_per_million', lambda p: p.sum() / countries.sum() * 100)).round(2)

sns.set_style("whitegrid")
bar, ax = plt.subplots(figsize=(11,100))
ax = sns.barplot(x="percentage",y=countries_per.index, data=countries_per, ci=None, palette='muted', orient = 'h')
ax.set_title("Relative frequency graph of Total cases per million")
```




    Text(0.5, 1.0, 'Relative frequency graph of Total cases per million')




![png](output_50_1.png)



```python
OWIDdf[OWIDdf.location=='Czechia'].tail(1)[['location','total_cases_per_million','new_cases_per_million','total_cases','population','total_deaths']]

```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>location</th>
      <th>total_cases_per_million</th>
      <th>new_cases_per_million</th>
      <th>total_cases</th>
      <th>population</th>
      <th>total_deaths</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>17933</th>
      <td>Czechia</td>
      <td>130645.284</td>
      <td>650.856</td>
      <td>1399078.0</td>
      <td>10708982.0</td>
      <td>23226.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
OWIDdf[OWIDdf.location=='Andorra'].tail(1)[['location','total_cases_per_million','new_cases_per_million','total_cases','population','total_deaths']]
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>location</th>
      <th>total_cases_per_million</th>
      <th>new_cases_per_million</th>
      <th>total_cases</th>
      <th>population</th>
      <th>total_deaths</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1926</th>
      <td>Andorra</td>
      <td>145809.875</td>
      <td>491.814</td>
      <td>11266.0</td>
      <td>77265.0</td>
      <td>113.0</td>
    </tr>
  </tbody>
</table>
</div>



if the population of the country is under 1 million, the value of total_cases_per_million is scaled up proportionally.b


```python
odfdt = odfdt[odfdt['total_cases_per_million'].notna()]
odfdt = odfdt[odfdt['population_density'].notna()]
```


```python
odfdt.population_density.max()
```




    19347.5




```python
px.scatter(odfdt,x='total_cases_per_million',y='population_density', size = 'population_density',
           color='location', hover_data=['location'],
           title='Population density vs total_cases_per_million')
```


<div>                            <div id="f3e52e34-25d5-46d3-b76c-4e17ff7c1456" class="plotly-graph-div" style="height:525px; width:100%;"></div>            <script type="text/javascript">                require(["plotly"], function(Plotly) {                    window.PLOTLYENV=window.PLOTLYENV || {};                                    if (document.getElementById("f3e52e34-25d5-46d3-b76c-4e17ff7c1456")) {                    Plotly.newPlot(                        "f3e52e34-25d5-46d3-b76c-4e17ff7c1456",                        [{"customdata": [["Afghanistan"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Afghanistan", "marker": {"color": "#636efa", "size": [54.422], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Afghanistan", "orientation": "v", "showlegend": true, "type": "scatter", "x": [1438.155], "xaxis": "x", "y": [54.422], "yaxis": "y"}, {"customdata": [["Albania"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Albania", "marker": {"color": "#EF553B", "size": [104.87100000000001], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Albania", "orientation": "v", "showlegend": true, "type": "scatter", "x": [40820.766], "xaxis": "x", "y": [104.87100000000001], "yaxis": "y"}, {"customdata": [["Algeria"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Algeria", "marker": {"color": "#00cc96", "size": [17.348], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Algeria", "orientation": "v", "showlegend": true, "type": "scatter", "x": [2628.558], "xaxis": "x", "y": [17.348], "yaxis": "y"}, {"customdata": [["Andorra"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Andorra", "marker": {"color": "#ab63fa", "size": [163.755], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Andorra", "orientation": "v", "showlegend": true, "type": "scatter", "x": [145809.875], "xaxis": "x", "y": [163.755], "yaxis": "y"}, {"customdata": [["Angola"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Angola", "marker": {"color": "#FFA15A", "size": [23.89], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Angola", "orientation": "v", "showlegend": true, "type": "scatter", "x": [650.515], "xaxis": "x", "y": [23.89], "yaxis": "y"}, {"customdata": [["Antigua and Barbuda"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Antigua and Barbuda", "marker": {"color": "#19d3f3", "size": [231.845], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Antigua and Barbuda", "orientation": "v", "showlegend": true, "type": "scatter", "x": [9833.755], "xaxis": "x", "y": [231.845], "yaxis": "y"}, {"customdata": [["Argentina"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Argentina", "marker": {"color": "#FF6692", "size": [16.177], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Argentina", "orientation": "v", "showlegend": true, "type": "scatter", "x": [48582.459], "xaxis": "x", "y": [16.177], "yaxis": "y"}, {"customdata": [["Armenia"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Armenia", "marker": {"color": "#B6E880", "size": [102.931], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Armenia", "orientation": "v", "showlegend": true, "type": "scatter", "x": [60199.431], "xaxis": "x", "y": [102.931], "yaxis": "y"}, {"customdata": [["Australia"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Australia", "marker": {"color": "#FF97FF", "size": [3.202], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Australia", "orientation": "v", "showlegend": true, "type": "scatter", "x": [1142.358], "xaxis": "x", "y": [3.202], "yaxis": "y"}, {"customdata": [["Austria"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Austria", "marker": {"color": "#FECB52", "size": [106.749], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Austria", "orientation": "v", "showlegend": true, "type": "scatter", "x": [54801.919], "xaxis": "x", "y": [106.749], "yaxis": "y"}, {"customdata": [["Azerbaijan"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Azerbaijan", "marker": {"color": "#636efa", "size": [119.309], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Azerbaijan", "orientation": "v", "showlegend": true, "type": "scatter", "x": [23699.66], "xaxis": "x", "y": [119.309], "yaxis": "y"}, {"customdata": [["Bahamas"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Bahamas", "marker": {"color": "#EF553B", "size": [39.497], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Bahamas", "orientation": "v", "showlegend": true, "type": "scatter", "x": [22016.641], "xaxis": "x", "y": [39.497], "yaxis": "y"}, {"customdata": [["Bahrain"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Bahrain", "marker": {"color": "#00cc96", "size": [1935.9070000000002], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Bahrain", "orientation": "v", "showlegend": true, "type": "scatter", "x": [76987.723], "xaxis": "x", "y": [1935.9070000000002], "yaxis": "y"}, {"customdata": [["Bangladesh"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Bangladesh", "marker": {"color": "#ab63fa", "size": [1265.036], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Bangladesh", "orientation": "v", "showlegend": true, "type": "scatter", "x": [3384.5229999999997], "xaxis": "x", "y": [1265.036], "yaxis": "y"}, {"customdata": [["Barbados"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Barbados", "marker": {"color": "#FFA15A", "size": [664.4630000000001], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Barbados", "orientation": "v", "showlegend": true, "type": "scatter", "x": [11904.472], "xaxis": "x", "y": [664.4630000000001], "yaxis": "y"}, {"customdata": [["Belarus"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Belarus", "marker": {"color": "#19d3f3", "size": [46.858000000000004], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Belarus", "orientation": "v", "showlegend": true, "type": "scatter", "x": [31994.151], "xaxis": "x", "y": [46.858000000000004], "yaxis": "y"}, {"customdata": [["Belgium"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Belgium", "marker": {"color": "#FF6692", "size": [375.564], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Belgium", "orientation": "v", "showlegend": true, "type": "scatter", "x": [69742.0], "xaxis": "x", "y": [375.564], "yaxis": "y"}, {"customdata": [["Belize"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Belize", "marker": {"color": "#B6E880", "size": [16.426], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Belize", "orientation": "v", "showlegend": true, "type": "scatter", "x": [31110.027000000002], "xaxis": "x", "y": [16.426], "yaxis": "y"}, {"customdata": [["Benin"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Benin", "marker": {"color": "#FF97FF", "size": [99.11], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Benin", "orientation": "v", "showlegend": true, "type": "scatter", "x": [536.245], "xaxis": "x", "y": [99.11], "yaxis": "y"}, {"customdata": [["Bhutan"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Bhutan", "marker": {"color": "#FECB52", "size": [21.188000000000002], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Bhutan", "orientation": "v", "showlegend": true, "type": "scatter", "x": [1124.9180000000001], "xaxis": "x", "y": [21.188000000000002], "yaxis": "y"}, {"customdata": [["Bolivia"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Bolivia", "marker": {"color": "#636efa", "size": [10.202], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Bolivia", "orientation": "v", "showlegend": true, "type": "scatter", "x": [22221.225], "xaxis": "x", "y": [10.202], "yaxis": "y"}, {"customdata": [["Bosnia and Herzegovina"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Bosnia and Herzegovina", "marker": {"color": "#EF553B", "size": [68.49600000000001], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Bosnia and Herzegovina", "orientation": "v", "showlegend": true, "type": "scatter", "x": [43330.697], "xaxis": "x", "y": [68.49600000000001], "yaxis": "y"}, {"customdata": [["Botswana"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Botswana", "marker": {"color": "#00cc96", "size": [4.044], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Botswana", "orientation": "v", "showlegend": true, "type": "scatter", "x": [14499.761], "xaxis": "x", "y": [4.044], "yaxis": "y"}, {"customdata": [["Brazil"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Brazil", "marker": {"color": "#ab63fa", "size": [25.04], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Brazil", "orientation": "v", "showlegend": true, "type": "scatter", "x": [54024.285], "xaxis": "x", "y": [25.04], "yaxis": "y"}, {"customdata": [["Brunei"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Brunei", "marker": {"color": "#FFA15A", "size": [81.347], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Brunei", "orientation": "v", "showlegend": true, "type": "scatter", "x": [454.875], "xaxis": "x", "y": [81.347], "yaxis": "y"}, {"customdata": [["Bulgaria"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Bulgaria", "marker": {"color": "#19d3f3", "size": [65.18], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Bulgaria", "orientation": "v", "showlegend": true, "type": "scatter", "x": [40089.113], "xaxis": "x", "y": [65.18], "yaxis": "y"}, {"customdata": [["Burkina Faso"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Burkina Faso", "marker": {"color": "#FF6692", "size": [70.15100000000001], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Burkina Faso", "orientation": "v", "showlegend": true, "type": "scatter", "x": [591.869], "xaxis": "x", "y": [70.15100000000001], "yaxis": "y"}, {"customdata": [["Burundi"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Burundi", "marker": {"color": "#B6E880", "size": [423.06199999999995], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Burundi", "orientation": "v", "showlegend": true, "type": "scatter", "x": [206.967], "xaxis": "x", "y": [423.06199999999995], "yaxis": "y"}, {"customdata": [["Cambodia"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Cambodia", "marker": {"color": "#FF97FF", "size": [90.67200000000001], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Cambodia", "orientation": "v", "showlegend": true, "type": "scatter", "x": [79.251], "xaxis": "x", "y": [90.67200000000001], "yaxis": "y"}, {"customdata": [["Cameroon"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Cameroon", "marker": {"color": "#FECB52", "size": [50.885], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Cameroon", "orientation": "v", "showlegend": true, "type": "scatter", "x": [1530.257], "xaxis": "x", "y": [50.885], "yaxis": "y"}, {"customdata": [["Canada"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Canada", "marker": {"color": "#636efa", "size": [4.037], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Canada", "orientation": "v", "showlegend": true, "type": "scatter", "x": [24232.717], "xaxis": "x", "y": [4.037], "yaxis": "y"}, {"customdata": [["Cape Verde"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Cape Verde", "marker": {"color": "#EF553B", "size": [135.58], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Cape Verde", "orientation": "v", "showlegend": true, "type": "scatter", "x": [28959.257999999998], "xaxis": "x", "y": [135.58], "yaxis": "y"}, {"customdata": [["Central African Republic"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Central African Republic", "marker": {"color": "#00cc96", "size": [7.479], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Central African Republic", "orientation": "v", "showlegend": true, "type": "scatter", "x": [1040.009], "xaxis": "x", "y": [7.479], "yaxis": "y"}, {"customdata": [["Chad"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Chad", "marker": {"color": "#ab63fa", "size": [11.833], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Chad", "orientation": "v", "showlegend": true, "type": "scatter", "x": [262.33], "xaxis": "x", "y": [11.833], "yaxis": "y"}, {"customdata": [["Chile"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Chile", "marker": {"color": "#FFA15A", "size": [24.281999999999996], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Chile", "orientation": "v", "showlegend": true, "type": "scatter", "x": [46615.414000000004], "xaxis": "x", "y": [24.281999999999996], "yaxis": "y"}, {"customdata": [["China"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "China", "marker": {"color": "#19d3f3", "size": [147.674], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "China", "orientation": "v", "showlegend": true, "type": "scatter", "x": [70.434], "xaxis": "x", "y": [147.674], "yaxis": "y"}, {"customdata": [["Colombia"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Colombia", "marker": {"color": "#FF6692", "size": [44.223], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Colombia", "orientation": "v", "showlegend": true, "type": "scatter", "x": [45263.629], "xaxis": "x", "y": [44.223], "yaxis": "y"}, {"customdata": [["Comoros"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Comoros", "marker": {"color": "#B6E880", "size": [437.352], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Comoros", "orientation": "v", "showlegend": true, "type": "scatter", "x": [4180.107], "xaxis": "x", "y": [437.352], "yaxis": "y"}, {"customdata": [["Congo"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Congo", "marker": {"color": "#FF97FF", "size": [15.405], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Congo", "orientation": "v", "showlegend": true, "type": "scatter", "x": [1690.621], "xaxis": "x", "y": [15.405], "yaxis": "y"}, {"customdata": [["Costa Rica"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Costa Rica", "marker": {"color": "#FECB52", "size": [96.079], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Costa Rica", "orientation": "v", "showlegend": true, "type": "scatter", "x": [41045.998999999996], "xaxis": "x", "y": [96.079], "yaxis": "y"}, {"customdata": [["Cote d'Ivoire"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Cote d'Ivoire", "marker": {"color": "#636efa", "size": [76.399], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Cote d'Ivoire", "orientation": "v", "showlegend": true, "type": "scatter", "x": [1427.425], "xaxis": "x", "y": [76.399], "yaxis": "y"}, {"customdata": [["Croatia"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Croatia", "marker": {"color": "#EF553B", "size": [73.726], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Croatia", "orientation": "v", "showlegend": true, "type": "scatter", "x": [61151.915], "xaxis": "x", "y": [73.726], "yaxis": "y"}, {"customdata": [["Cuba"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Cuba", "marker": {"color": "#00cc96", "size": [110.40799999999999], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Cuba", "orientation": "v", "showlegend": true, "type": "scatter", "x": [5427.217], "xaxis": "x", "y": [110.40799999999999], "yaxis": "y"}, {"customdata": [["Cyprus"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Cyprus", "marker": {"color": "#ab63fa", "size": [127.65700000000001], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Cyprus", "orientation": "v", "showlegend": true, "type": "scatter", "x": [45268.918], "xaxis": "x", "y": [127.65700000000001], "yaxis": "y"}, {"customdata": [["Czechia"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Czechia", "marker": {"color": "#FFA15A", "size": [137.17600000000002], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Czechia", "orientation": "v", "showlegend": true, "type": "scatter", "x": [130645.284], "xaxis": "x", "y": [137.17600000000002], "yaxis": "y"}, {"customdata": [["Democratic Republic of Congo"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Democratic Republic of Congo", "marker": {"color": "#19d3f3", "size": [35.879], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Democratic Republic of Congo", "orientation": "v", "showlegend": true, "type": "scatter", "x": [301.625], "xaxis": "x", "y": [35.879], "yaxis": "y"}, {"customdata": [["Denmark"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Denmark", "marker": {"color": "#FF6692", "size": [136.52], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Denmark", "orientation": "v", "showlegend": true, "type": "scatter", "x": [38180.81], "xaxis": "x", "y": [136.52], "yaxis": "y"}, {"customdata": [["Djibouti"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Djibouti", "marker": {"color": "#B6E880", "size": [41.285], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Djibouti", "orientation": "v", "showlegend": true, "type": "scatter", "x": [6344.116999999999], "xaxis": "x", "y": [41.285], "yaxis": "y"}, {"customdata": [["Dominica"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Dominica", "marker": {"color": "#FF97FF", "size": [98.56700000000001], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Dominica", "orientation": "v", "showlegend": true, "type": "scatter", "x": [2166.938], "xaxis": "x", "y": [98.56700000000001], "yaxis": "y"}, {"customdata": [["Dominican Republic"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Dominican Republic", "marker": {"color": "#FECB52", "size": [222.873], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Dominican Republic", "orientation": "v", "showlegend": true, "type": "scatter", "x": [22681.34], "xaxis": "x", "y": [222.873], "yaxis": "y"}, {"customdata": [["Ecuador"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Ecuador", "marker": {"color": "#636efa", "size": [66.939], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Ecuador", "orientation": "v", "showlegend": true, "type": "scatter", "x": [17129.738], "xaxis": "x", "y": [66.939], "yaxis": "y"}, {"customdata": [["Egypt"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Egypt", "marker": {"color": "#EF553B", "size": [97.999], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Egypt", "orientation": "v", "showlegend": true, "type": "scatter", "x": [1865.6870000000001], "xaxis": "x", "y": [97.999], "yaxis": "y"}, {"customdata": [["El Salvador"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "El Salvador", "marker": {"color": "#00cc96", "size": [307.811], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "El Salvador", "orientation": "v", "showlegend": true, "type": "scatter", "x": [9572.013], "xaxis": "x", "y": [307.811], "yaxis": "y"}, {"customdata": [["Equatorial Guinea"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Equatorial Guinea", "marker": {"color": "#ab63fa", "size": [45.193999999999996], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Equatorial Guinea", "orientation": "v", "showlegend": true, "type": "scatter", "x": [4677.17], "xaxis": "x", "y": [45.193999999999996], "yaxis": "y"}, {"customdata": [["Eritrea"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Eritrea", "marker": {"color": "#FFA15A", "size": [44.303999999999995], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Eritrea", "orientation": "v", "showlegend": true, "type": "scatter", "x": [856.637], "xaxis": "x", "y": [44.303999999999995], "yaxis": "y"}, {"customdata": [["Estonia"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Estonia", "marker": {"color": "#19d3f3", "size": [31.033], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Estonia", "orientation": "v", "showlegend": true, "type": "scatter", "x": [63931.027], "xaxis": "x", "y": [31.033], "yaxis": "y"}, {"customdata": [["Eswatini"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Eswatini", "marker": {"color": "#FF6692", "size": [79.492], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Eswatini", "orientation": "v", "showlegend": true, "type": "scatter", "x": [14857.382], "xaxis": "x", "y": [79.492], "yaxis": "y"}, {"customdata": [["Ethiopia"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Ethiopia", "marker": {"color": "#B6E880", "size": [104.95700000000001], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Ethiopia", "orientation": "v", "showlegend": true, "type": "scatter", "x": [1526.283], "xaxis": "x", "y": [104.95700000000001], "yaxis": "y"}, {"customdata": [["Fiji"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Fiji", "marker": {"color": "#FF97FF", "size": [49.562], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Fiji", "orientation": "v", "showlegend": true, "type": "scatter", "x": [73.624], "xaxis": "x", "y": [49.562], "yaxis": "y"}, {"customdata": [["Finland"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Finland", "marker": {"color": "#FECB52", "size": [18.136], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Finland", "orientation": "v", "showlegend": true, "type": "scatter", "x": [12068.652], "xaxis": "x", "y": [18.136], "yaxis": "y"}, {"customdata": [["France"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "France", "marker": {"color": "#636efa", "size": [122.57799999999999], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "France", "orientation": "v", "showlegend": true, "type": "scatter", "x": [63300.93], "xaxis": "x", "y": [122.57799999999999], "yaxis": "y"}, {"customdata": [["Gabon"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Gabon", "marker": {"color": "#EF553B", "size": [7.859], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Gabon", "orientation": "v", "showlegend": true, "type": "scatter", "x": [7485.191], "xaxis": "x", "y": [7.859], "yaxis": "y"}, {"customdata": [["Gambia"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Gambia", "marker": {"color": "#00cc96", "size": [207.56599999999997], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Gambia", "orientation": "v", "showlegend": true, "type": "scatter", "x": [2062.761], "xaxis": "x", "y": [207.56599999999997], "yaxis": "y"}, {"customdata": [["Georgia"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Georgia", "marker": {"color": "#ab63fa", "size": [65.032], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Georgia", "orientation": "v", "showlegend": true, "type": "scatter", "x": [68933.802], "xaxis": "x", "y": [65.032], "yaxis": "y"}, {"customdata": [["Germany"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Germany", "marker": {"color": "#FFA15A", "size": [237.016], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Germany", "orientation": "v", "showlegend": true, "type": "scatter", "x": [30779.667999999998], "xaxis": "x", "y": [237.016], "yaxis": "y"}, {"customdata": [["Ghana"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Ghana", "marker": {"color": "#19d3f3", "size": [126.719], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Ghana", "orientation": "v", "showlegend": true, "type": "scatter", "x": [2824.386], "xaxis": "x", "y": [126.719], "yaxis": "y"}, {"customdata": [["Greece"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Greece", "marker": {"color": "#FF6692", "size": [83.479], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Greece", "orientation": "v", "showlegend": true, "type": "scatter", "x": [21217.097999999998], "xaxis": "x", "y": [83.479], "yaxis": "y"}, {"customdata": [["Grenada"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Grenada", "marker": {"color": "#B6E880", "size": [317.132], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Grenada", "orientation": "v", "showlegend": true, "type": "scatter", "x": [1315.3329999999999], "xaxis": "x", "y": [317.132], "yaxis": "y"}, {"customdata": [["Guatemala"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Guatemala", "marker": {"color": "#FF97FF", "size": [157.834], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Guatemala", "orientation": "v", "showlegend": true, "type": "scatter", "x": [10207.938], "xaxis": "x", "y": [157.834], "yaxis": "y"}, {"customdata": [["Guinea"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Guinea", "marker": {"color": "#FECB52", "size": [51.755], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Guinea", "orientation": "v", "showlegend": true, "type": "scatter", "x": [1350.969], "xaxis": "x", "y": [51.755], "yaxis": "y"}, {"customdata": [["Guinea-Bissau"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Guinea-Bissau", "marker": {"color": "#636efa", "size": [66.191], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Guinea-Bissau", "orientation": "v", "showlegend": true, "type": "scatter", "x": [1751.526], "xaxis": "x", "y": [66.191], "yaxis": "y"}, {"customdata": [["Guyana"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Guyana", "marker": {"color": "#EF553B", "size": [3.952], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Guyana", "orientation": "v", "showlegend": true, "type": "scatter", "x": [11645.662], "xaxis": "x", "y": [3.952], "yaxis": "y"}, {"customdata": [["Haiti"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Haiti", "marker": {"color": "#00cc96", "size": [398.44800000000004], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Haiti", "orientation": "v", "showlegend": true, "type": "scatter", "x": [1107.8239999999998], "xaxis": "x", "y": [398.44800000000004], "yaxis": "y"}, {"customdata": [["Honduras"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Honduras", "marker": {"color": "#ab63fa", "size": [82.805], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Honduras", "orientation": "v", "showlegend": true, "type": "scatter", "x": [17999.4], "xaxis": "x", "y": [82.805], "yaxis": "y"}, {"customdata": [["Hungary"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Hungary", "marker": {"color": "#FFA15A", "size": [108.04299999999999], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Hungary", "orientation": "v", "showlegend": true, "type": "scatter", "x": [53464.937000000005], "xaxis": "x", "y": [108.04299999999999], "yaxis": "y"}, {"customdata": [["Iceland"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Iceland", "marker": {"color": "#19d3f3", "size": [3.404], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Iceland", "orientation": "v", "showlegend": true, "type": "scatter", "x": [17793.407], "xaxis": "x", "y": [3.404], "yaxis": "y"}, {"customdata": [["India"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "India", "marker": {"color": "#FF6692", "size": [450.41900000000004], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "India", "orientation": "v", "showlegend": true, "type": "scatter", "x": [8250.219000000001], "xaxis": "x", "y": [450.41900000000004], "yaxis": "y"}, {"customdata": [["Indonesia"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Indonesia", "marker": {"color": "#B6E880", "size": [145.725], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Indonesia", "orientation": "v", "showlegend": true, "type": "scatter", "x": [5189.515], "xaxis": "x", "y": [145.725], "yaxis": "y"}, {"customdata": [["Iran"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Iran", "marker": {"color": "#FF97FF", "size": [49.831], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Iran", "orientation": "v", "showlegend": true, "type": "scatter", "x": [20798.804], "xaxis": "x", "y": [49.831], "yaxis": "y"}, {"customdata": [["Iraq"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Iraq", "marker": {"color": "#FECB52", "size": [88.125], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Iraq", "orientation": "v", "showlegend": true, "type": "scatter", "x": [18849.747], "xaxis": "x", "y": [88.125], "yaxis": "y"}, {"customdata": [["Ireland"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Ireland", "marker": {"color": "#636efa", "size": [69.874], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Ireland", "orientation": "v", "showlegend": true, "type": "scatter", "x": [45919.475], "xaxis": "x", "y": [69.874], "yaxis": "y"}, {"customdata": [["Israel"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Israel", "marker": {"color": "#EF553B", "size": [402.606], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Israel", "orientation": "v", "showlegend": true, "type": "scatter", "x": [94618.811], "xaxis": "x", "y": [402.606], "yaxis": "y"}, {"customdata": [["Italy"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Italy", "marker": {"color": "#00cc96", "size": [205.859], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Italy", "orientation": "v", "showlegend": true, "type": "scatter", "x": [53308.709], "xaxis": "x", "y": [205.859], "yaxis": "y"}, {"customdata": [["Jamaica"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Jamaica", "marker": {"color": "#ab63fa", "size": [266.879], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Jamaica", "orientation": "v", "showlegend": true, "type": "scatter", "x": [10299.676], "xaxis": "x", "y": [266.879], "yaxis": "y"}, {"customdata": [["Japan"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Japan", "marker": {"color": "#FFA15A", "size": [347.778], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Japan", "orientation": "v", "showlegend": true, "type": "scatter", "x": [3536.5240000000003], "xaxis": "x", "y": [347.778], "yaxis": "y"}, {"customdata": [["Jordan"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Jordan", "marker": {"color": "#19d3f3", "size": [109.285], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Jordan", "orientation": "v", "showlegend": true, "type": "scatter", "x": [46755.509000000005], "xaxis": "x", "y": [109.285], "yaxis": "y"}, {"customdata": [["Kazakhstan"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Kazakhstan", "marker": {"color": "#FF6692", "size": [6.681], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Kazakhstan", "orientation": "v", "showlegend": true, "type": "scatter", "x": [14621.36], "xaxis": "x", "y": [6.681], "yaxis": "y"}, {"customdata": [["Kenya"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Kenya", "marker": {"color": "#B6E880", "size": [87.324], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Kenya", "orientation": "v", "showlegend": true, "type": "scatter", "x": [2105.882], "xaxis": "x", "y": [87.324], "yaxis": "y"}, {"customdata": [["Kosovo"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Kosovo", "marker": {"color": "#FF97FF", "size": [168.155], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Kosovo", "orientation": "v", "showlegend": true, "type": "scatter", "x": [39357.937999999995], "xaxis": "x", "y": [168.155], "yaxis": "y"}, {"customdata": [["Kuwait"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Kuwait", "marker": {"color": "#FECB52", "size": [232.128], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Kuwait", "orientation": "v", "showlegend": true, "type": "scatter", "x": [49062.149000000005], "xaxis": "x", "y": [232.128], "yaxis": "y"}, {"customdata": [["Kyrgyzstan"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Kyrgyzstan", "marker": {"color": "#636efa", "size": [32.333], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Kyrgyzstan", "orientation": "v", "showlegend": true, "type": "scatter", "x": [13311.995], "xaxis": "x", "y": [32.333], "yaxis": "y"}, {"customdata": [["Laos"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Laos", "marker": {"color": "#EF553B", "size": [29.715], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Laos", "orientation": "v", "showlegend": true, "type": "scatter", "x": [6.597], "xaxis": "x", "y": [29.715], "yaxis": "y"}, {"customdata": [["Latvia"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Latvia", "marker": {"color": "#00cc96", "size": [31.212], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Latvia", "orientation": "v", "showlegend": true, "type": "scatter", "x": [49719.489], "xaxis": "x", "y": [31.212], "yaxis": "y"}, {"customdata": [["Lebanon"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Lebanon", "marker": {"color": "#ab63fa", "size": [594.561], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Lebanon", "orientation": "v", "showlegend": true, "type": "scatter", "x": [61307.092000000004], "xaxis": "x", "y": [594.561], "yaxis": "y"}, {"customdata": [["Lesotho"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Lesotho", "marker": {"color": "#FFA15A", "size": [73.562], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Lesotho", "orientation": "v", "showlegend": true, "type": "scatter", "x": [4915.388], "xaxis": "x", "y": [73.562], "yaxis": "y"}, {"customdata": [["Liberia"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Liberia", "marker": {"color": "#19d3f3", "size": [49.126999999999995], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Liberia", "orientation": "v", "showlegend": true, "type": "scatter", "x": [401.37], "xaxis": "x", "y": [49.126999999999995], "yaxis": "y"}, {"customdata": [["Libya"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Libya", "marker": {"color": "#FF6692", "size": [3.623], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Libya", "orientation": "v", "showlegend": true, "type": "scatter", "x": [21101.287], "xaxis": "x", "y": [3.623], "yaxis": "y"}, {"customdata": [["Liechtenstein"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Liechtenstein", "marker": {"color": "#B6E880", "size": [237.012], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Liechtenstein", "orientation": "v", "showlegend": true, "type": "scatter", "x": [68489.918], "xaxis": "x", "y": [237.012], "yaxis": "y"}, {"customdata": [["Lithuania"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Lithuania", "marker": {"color": "#FF97FF", "size": [45.135], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Lithuania", "orientation": "v", "showlegend": true, "type": "scatter", "x": [75445.645], "xaxis": "x", "y": [45.135], "yaxis": "y"}, {"customdata": [["Luxembourg"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Luxembourg", "marker": {"color": "#FECB52", "size": [231.447], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Luxembourg", "orientation": "v", "showlegend": true, "type": "scatter", "x": [91861.349], "xaxis": "x", "y": [231.447], "yaxis": "y"}, {"customdata": [["Madagascar"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Madagascar", "marker": {"color": "#636efa", "size": [43.951], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Madagascar", "orientation": "v", "showlegend": true, "type": "scatter", "x": [771.225], "xaxis": "x", "y": [43.951], "yaxis": "y"}, {"customdata": [["Malawi"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Malawi", "marker": {"color": "#EF553B", "size": [197.519], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Malawi", "orientation": "v", "showlegend": true, "type": "scatter", "x": [1714.013], "xaxis": "x", "y": [197.519], "yaxis": "y"}, {"customdata": [["Malaysia"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Malaysia", "marker": {"color": "#00cc96", "size": [96.25399999999999], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Malaysia", "orientation": "v", "showlegend": true, "type": "scatter", "x": [10003.183], "xaxis": "x", "y": [96.25399999999999], "yaxis": "y"}, {"customdata": [["Maldives"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Maldives", "marker": {"color": "#ab63fa", "size": [1454.433], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Maldives", "orientation": "v", "showlegend": true, "type": "scatter", "x": [39908.092000000004], "xaxis": "x", "y": [1454.433], "yaxis": "y"}, {"customdata": [["Mali"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Mali", "marker": {"color": "#FFA15A", "size": [15.196], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Mali", "orientation": "v", "showlegend": true, "type": "scatter", "x": [440.13], "xaxis": "x", "y": [15.196], "yaxis": "y"}, {"customdata": [["Malta"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Malta", "marker": {"color": "#19d3f3", "size": [1454.037], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Malta", "orientation": "v", "showlegend": true, "type": "scatter", "x": [60096.617], "xaxis": "x", "y": [1454.037], "yaxis": "y"}, {"customdata": [["Marshall Islands"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Marshall Islands", "marker": {"color": "#FF6692", "size": [295.15], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Marshall Islands", "orientation": "v", "showlegend": true, "type": "scatter", "x": [67.574], "xaxis": "x", "y": [295.15], "yaxis": "y"}, {"customdata": [["Mauritania"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Mauritania", "marker": {"color": "#B6E880", "size": [4.289], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Mauritania", "orientation": "v", "showlegend": true, "type": "scatter", "x": [3750.382], "xaxis": "x", "y": [4.289], "yaxis": "y"}, {"customdata": [["Mauritius"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Mauritius", "marker": {"color": "#FF97FF", "size": [622.962], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Mauritius", "orientation": "v", "showlegend": true, "type": "scatter", "x": [583.44], "xaxis": "x", "y": [622.962], "yaxis": "y"}, {"customdata": [["Mexico"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Mexico", "marker": {"color": "#FECB52", "size": [66.444], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Mexico", "orientation": "v", "showlegend": true, "type": "scatter", "x": [16801.703999999998], "xaxis": "x", "y": [66.444], "yaxis": "y"}, {"customdata": [["Micronesia (country)"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Micronesia (country)", "marker": {"color": "#636efa", "size": [150.77700000000002], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Micronesia (country)", "orientation": "v", "showlegend": true, "type": "scatter", "x": [8.693999999999999], "xaxis": "x", "y": [150.77700000000002], "yaxis": "y"}, {"customdata": [["Moldova"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Moldova", "marker": {"color": "#EF553B", "size": [123.655], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Moldova", "orientation": "v", "showlegend": true, "type": "scatter", "x": [50685.393], "xaxis": "x", "y": [123.655], "yaxis": "y"}, {"customdata": [["Monaco"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Monaco", "marker": {"color": "#00cc96", "size": [19347.5], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Monaco", "orientation": "v", "showlegend": true, "type": "scatter", "x": [53689.736], "xaxis": "x", "y": [19347.5], "yaxis": "y"}, {"customdata": [["Mongolia"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Mongolia", "marker": {"color": "#ab63fa", "size": [1.98], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Mongolia", "orientation": "v", "showlegend": true, "type": "scatter", "x": [1245.4660000000001], "xaxis": "x", "y": [1.98], "yaxis": "y"}, {"customdata": [["Montenegro"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Montenegro", "marker": {"color": "#FFA15A", "size": [46.28], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Montenegro", "orientation": "v", "showlegend": true, "type": "scatter", "x": [133255.952], "xaxis": "x", "y": [46.28], "yaxis": "y"}, {"customdata": [["Morocco"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Morocco", "marker": {"color": "#19d3f3", "size": [80.08], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Morocco", "orientation": "v", "showlegend": true, "type": "scatter", "x": [13246.535], "xaxis": "x", "y": [80.08], "yaxis": "y"}, {"customdata": [["Mozambique"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Mozambique", "marker": {"color": "#FF6692", "size": [37.728], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Mozambique", "orientation": "v", "showlegend": true, "type": "scatter", "x": [2064.153], "xaxis": "x", "y": [37.728], "yaxis": "y"}, {"customdata": [["Myanmar"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Myanmar", "marker": {"color": "#B6E880", "size": [81.721], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Myanmar", "orientation": "v", "showlegend": true, "type": "scatter", "x": [2612.526], "xaxis": "x", "y": [81.721], "yaxis": "y"}, {"customdata": [["Namibia"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Namibia", "marker": {"color": "#FF97FF", "size": [3.0780000000000003], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Namibia", "orientation": "v", "showlegend": true, "type": "scatter", "x": [16214.625], "xaxis": "x", "y": [3.0780000000000003], "yaxis": "y"}, {"customdata": [["Nepal"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Nepal", "marker": {"color": "#FECB52", "size": [204.43], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Nepal", "orientation": "v", "showlegend": true, "type": "scatter", "x": [9446.162], "xaxis": "x", "y": [204.43], "yaxis": "y"}, {"customdata": [["Netherlands"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Netherlands", "marker": {"color": "#636efa", "size": [508.54400000000004], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Netherlands", "orientation": "v", "showlegend": true, "type": "scatter", "x": [68455.424], "xaxis": "x", "y": [508.54400000000004], "yaxis": "y"}, {"customdata": [["New Zealand"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "New Zealand", "marker": {"color": "#EF553B", "size": [18.206], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "New Zealand", "orientation": "v", "showlegend": true, "type": "scatter", "x": [503.916], "xaxis": "x", "y": [18.206], "yaxis": "y"}, {"customdata": [["Nicaragua"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Nicaragua", "marker": {"color": "#00cc96", "size": [51.667], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Nicaragua", "orientation": "v", "showlegend": true, "type": "scatter", "x": [986.783], "xaxis": "x", "y": [51.667], "yaxis": "y"}, {"customdata": [["Niger"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Niger", "marker": {"color": "#ab63fa", "size": [16.955], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Niger", "orientation": "v", "showlegend": true, "type": "scatter", "x": [200.771], "xaxis": "x", "y": [16.955], "yaxis": "y"}, {"customdata": [["Nigeria"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Nigeria", "marker": {"color": "#FFA15A", "size": [209.588], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Nigeria", "orientation": "v", "showlegend": true, "type": "scatter", "x": [779.36], "xaxis": "x", "y": [209.588], "yaxis": "y"}, {"customdata": [["North Macedonia"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "North Macedonia", "marker": {"color": "#19d3f3", "size": [82.6], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "North Macedonia", "orientation": "v", "showlegend": true, "type": "scatter", "x": [54068.869000000006], "xaxis": "x", "y": [82.6], "yaxis": "y"}, {"customdata": [["Norway"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Norway", "marker": {"color": "#FF6692", "size": [14.462], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Norway", "orientation": "v", "showlegend": true, "type": "scatter", "x": [14837.928], "xaxis": "x", "y": [14.462], "yaxis": "y"}, {"customdata": [["Oman"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Oman", "marker": {"color": "#B6E880", "size": [14.98], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Oman", "orientation": "v", "showlegend": true, "type": "scatter", "x": [28760.107999999997], "xaxis": "x", "y": [14.98], "yaxis": "y"}, {"customdata": [["Pakistan"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Pakistan", "marker": {"color": "#FF97FF", "size": [255.57299999999998], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Pakistan", "orientation": "v", "showlegend": true, "type": "scatter", "x": [2749.9959999999996], "xaxis": "x", "y": [255.57299999999998], "yaxis": "y"}, {"customdata": [["Palestine"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Palestine", "marker": {"color": "#FECB52", "size": [778.202], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Palestine", "orientation": "v", "showlegend": true, "type": "scatter", "x": [41028.609], "xaxis": "x", "y": [778.202], "yaxis": "y"}, {"customdata": [["Panama"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Panama", "marker": {"color": "#636efa", "size": [55.133], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Panama", "orientation": "v", "showlegend": true, "type": "scatter", "x": [80634.463], "xaxis": "x", "y": [55.133], "yaxis": "y"}, {"customdata": [["Papua New Guinea"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Papua New Guinea", "marker": {"color": "#EF553B", "size": [18.22], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Papua New Guinea", "orientation": "v", "showlegend": true, "type": "scatter", "x": [242.87400000000002], "xaxis": "x", "y": [18.22], "yaxis": "y"}, {"customdata": [["Paraguay"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Paraguay", "marker": {"color": "#00cc96", "size": [17.144000000000002], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Paraguay", "orientation": "v", "showlegend": true, "type": "scatter", "x": [25238.45], "xaxis": "x", "y": [17.144000000000002], "yaxis": "y"}, {"customdata": [["Peru"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Peru", "marker": {"color": "#ab63fa", "size": [25.129], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Peru", "orientation": "v", "showlegend": true, "type": "scatter", "x": [42701.977], "xaxis": "x", "y": [25.129], "yaxis": "y"}, {"customdata": [["Philippines"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Philippines", "marker": {"color": "#FFA15A", "size": [351.87300000000005], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Philippines", "orientation": "v", "showlegend": true, "type": "scatter", "x": [5671.581], "xaxis": "x", "y": [351.87300000000005], "yaxis": "y"}, {"customdata": [["Poland"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Poland", "marker": {"color": "#19d3f3", "size": [124.027], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Poland", "orientation": "v", "showlegend": true, "type": "scatter", "x": [50377.887], "xaxis": "x", "y": [124.027], "yaxis": "y"}, {"customdata": [["Portugal"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Portugal", "marker": {"color": "#FF6692", "size": [112.37100000000001], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Portugal", "orientation": "v", "showlegend": true, "type": "scatter", "x": [79854.898], "xaxis": "x", "y": [112.37100000000001], "yaxis": "y"}, {"customdata": [["Qatar"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Qatar", "marker": {"color": "#B6E880", "size": [227.322], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Qatar", "orientation": "v", "showlegend": true, "type": "scatter", "x": [59093.528], "xaxis": "x", "y": [227.322], "yaxis": "y"}, {"customdata": [["Romania"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Romania", "marker": {"color": "#FF97FF", "size": [85.12899999999999], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Romania", "orientation": "v", "showlegend": true, "type": "scatter", "x": [44688.804000000004], "xaxis": "x", "y": [85.12899999999999], "yaxis": "y"}, {"customdata": [["Russia"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Russia", "marker": {"color": "#FECB52", "size": [8.823], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Russia", "orientation": "v", "showlegend": true, "type": "scatter", "x": [29748.841], "xaxis": "x", "y": [8.823], "yaxis": "y"}, {"customdata": [["Rwanda"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Rwanda", "marker": {"color": "#636efa", "size": [494.869], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Rwanda", "orientation": "v", "showlegend": true, "type": "scatter", "x": [1558.499], "xaxis": "x", "y": [494.869], "yaxis": "y"}, {"customdata": [["Saint Kitts and Nevis"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Saint Kitts and Nevis", "marker": {"color": "#EF553B", "size": [212.865], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Saint Kitts and Nevis", "orientation": "v", "showlegend": true, "type": "scatter", "x": [808.3919999999999], "xaxis": "x", "y": [212.865], "yaxis": "y"}, {"customdata": [["Saint Lucia"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Saint Lucia", "marker": {"color": "#00cc96", "size": [293.187], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Saint Lucia", "orientation": "v", "showlegend": true, "type": "scatter", "x": [21951.87], "xaxis": "x", "y": [293.187], "yaxis": "y"}, {"customdata": [["Saint Vincent and the Grenadines"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Saint Vincent and the Grenadines", "marker": {"color": "#ab63fa", "size": [281.78700000000003], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Saint Vincent and the Grenadines", "orientation": "v", "showlegend": true, "type": "scatter", "x": [15142.365], "xaxis": "x", "y": [281.78700000000003], "yaxis": "y"}, {"customdata": [["Samoa"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Samoa", "marker": {"color": "#FFA15A", "size": [69.413], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Samoa", "orientation": "v", "showlegend": true, "type": "scatter", "x": [15.12], "xaxis": "x", "y": [69.413], "yaxis": "y"}, {"customdata": [["San Marino"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "San Marino", "marker": {"color": "#19d3f3", "size": [556.6669999999999], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "San Marino", "orientation": "v", "showlegend": true, "type": "scatter", "x": [121574.636], "xaxis": "x", "y": [556.6669999999999], "yaxis": "y"}, {"customdata": [["Sao Tome and Principe"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Sao Tome and Principe", "marker": {"color": "#FF6692", "size": [212.84099999999998], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Sao Tome and Principe", "orientation": "v", "showlegend": true, "type": "scatter", "x": [9481.614], "xaxis": "x", "y": [212.84099999999998], "yaxis": "y"}, {"customdata": [["Saudi Arabia"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Saudi Arabia", "marker": {"color": "#B6E880", "size": [15.322000000000001], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Saudi Arabia", "orientation": "v", "showlegend": true, "type": "scatter", "x": [10984.33], "xaxis": "x", "y": [15.322000000000001], "yaxis": "y"}, {"customdata": [["Senegal"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Senegal", "marker": {"color": "#FF97FF", "size": [82.32799999999999], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Senegal", "orientation": "v", "showlegend": true, "type": "scatter", "x": [2203.306], "xaxis": "x", "y": [82.32799999999999], "yaxis": "y"}, {"customdata": [["Serbia"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Serbia", "marker": {"color": "#FECB52", "size": [80.291], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Serbia", "orientation": "v", "showlegend": true, "type": "scatter", "x": [75871.808], "xaxis": "x", "y": [80.291], "yaxis": "y"}, {"customdata": [["Seychelles"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Seychelles", "marker": {"color": "#636efa", "size": [208.354], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Seychelles", "orientation": "v", "showlegend": true, "type": "scatter", "x": [33709.579], "xaxis": "x", "y": [208.354], "yaxis": "y"}, {"customdata": [["Sierra Leone"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Sierra Leone", "marker": {"color": "#EF553B", "size": [104.7], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Sierra Leone", "orientation": "v", "showlegend": true, "type": "scatter", "x": [493.545], "xaxis": "x", "y": [104.7], "yaxis": "y"}, {"customdata": [["Singapore"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Singapore", "marker": {"color": "#00cc96", "size": [7915.731], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Singapore", "orientation": "v", "showlegend": true, "type": "scatter", "x": [10273.757], "xaxis": "x", "y": [7915.731], "yaxis": "y"}, {"customdata": [["Slovakia"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Slovakia", "marker": {"color": "#ab63fa", "size": [113.12799999999999], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Slovakia", "orientation": "v", "showlegend": true, "type": "scatter", "x": [61817.778], "xaxis": "x", "y": [113.12799999999999], "yaxis": "y"}, {"customdata": [["Slovenia"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Slovenia", "marker": {"color": "#FFA15A", "size": [102.619], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Slovenia", "orientation": "v", "showlegend": true, "type": "scatter", "x": [96383.14300000001], "xaxis": "x", "y": [102.619], "yaxis": "y"}, {"customdata": [["Solomon Islands"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Solomon Islands", "marker": {"color": "#19d3f3", "size": [21.840999999999998], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Solomon Islands", "orientation": "v", "showlegend": true, "type": "scatter", "x": [26.206], "xaxis": "x", "y": [21.840999999999998], "yaxis": "y"}, {"customdata": [["Somalia"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Somalia", "marker": {"color": "#FF6692", "size": [23.5], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Somalia", "orientation": "v", "showlegend": true, "type": "scatter", "x": [578.234], "xaxis": "x", "y": [23.5], "yaxis": "y"}, {"customdata": [["South Africa"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "South Africa", "marker": {"color": "#B6E880", "size": [46.754], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "South Africa", "orientation": "v", "showlegend": true, "type": "scatter", "x": [25787.452], "xaxis": "x", "y": [46.754], "yaxis": "y"}, {"customdata": [["South Korea"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "South Korea", "marker": {"color": "#FF97FF", "size": [527.967], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "South Korea", "orientation": "v", "showlegend": true, "type": "scatter", "x": [1872.8010000000002], "xaxis": "x", "y": [527.967], "yaxis": "y"}, {"customdata": [["Spain"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Spain", "marker": {"color": "#FECB52", "size": [93.105], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Spain", "orientation": "v", "showlegend": true, "type": "scatter", "x": [68093.65400000001], "xaxis": "x", "y": [93.105], "yaxis": "y"}, {"customdata": [["Sri Lanka"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Sri Lanka", "marker": {"color": "#636efa", "size": [341.955], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Sri Lanka", "orientation": "v", "showlegend": true, "type": "scatter", "x": [4105.262], "xaxis": "x", "y": [341.955], "yaxis": "y"}, {"customdata": [["Sudan"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Sudan", "marker": {"color": "#EF553B", "size": [23.258000000000003], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Sudan", "orientation": "v", "showlegend": true, "type": "scatter", "x": [704.071], "xaxis": "x", "y": [23.258000000000003], "yaxis": "y"}, {"customdata": [["Suriname"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Suriname", "marker": {"color": "#00cc96", "size": [3.612], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Suriname", "orientation": "v", "showlegend": true, "type": "scatter", "x": [15382.675], "xaxis": "x", "y": [3.612], "yaxis": "y"}, {"customdata": [["Sweden"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Sweden", "marker": {"color": "#ab63fa", "size": [24.718000000000004], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Sweden", "orientation": "v", "showlegend": true, "type": "scatter", "x": [70552.327], "xaxis": "x", "y": [24.718000000000004], "yaxis": "y"}, {"customdata": [["Switzerland"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Switzerland", "marker": {"color": "#FFA15A", "size": [214.243], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Switzerland", "orientation": "v", "showlegend": true, "type": "scatter", "x": [65935.319], "xaxis": "x", "y": [214.243], "yaxis": "y"}, {"customdata": [["Tajikistan"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Tajikistan", "marker": {"color": "#19d3f3", "size": [64.281], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Tajikistan", "orientation": "v", "showlegend": true, "type": "scatter", "x": [1395.3129999999999], "xaxis": "x", "y": [64.281], "yaxis": "y"}, {"customdata": [["Tanzania"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Tanzania", "marker": {"color": "#FF6692", "size": [64.699], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Tanzania", "orientation": "v", "showlegend": true, "type": "scatter", "x": [8.521], "xaxis": "x", "y": [64.699], "yaxis": "y"}, {"customdata": [["Thailand"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Thailand", "marker": {"color": "#B6E880", "size": [135.132], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Thailand", "orientation": "v", "showlegend": true, "type": "scatter", "x": [386.89099999999996], "xaxis": "x", "y": [135.132], "yaxis": "y"}, {"customdata": [["Timor"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Timor", "marker": {"color": "#FF97FF", "size": [87.176], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Timor", "orientation": "v", "showlegend": true, "type": "scatter", "x": [148.66], "xaxis": "x", "y": [87.176], "yaxis": "y"}, {"customdata": [["Togo"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Togo", "marker": {"color": "#FECB52", "size": [143.366], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Togo", "orientation": "v", "showlegend": true, "type": "scatter", "x": [974.7860000000001], "xaxis": "x", "y": [143.366], "yaxis": "y"}, {"customdata": [["Trinidad and Tobago"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Trinidad and Tobago", "marker": {"color": "#636efa", "size": [266.88599999999997], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Trinidad and Tobago", "orientation": "v", "showlegend": true, "type": "scatter", "x": [5561.308000000001], "xaxis": "x", "y": [266.88599999999997], "yaxis": "y"}, {"customdata": [["Tunisia"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Tunisia", "marker": {"color": "#EF553B", "size": [74.22800000000001], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Tunisia", "orientation": "v", "showlegend": true, "type": "scatter", "x": [20462.122], "xaxis": "x", "y": [74.22800000000001], "yaxis": "y"}, {"customdata": [["Turkey"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Turkey", "marker": {"color": "#00cc96", "size": [104.914], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Turkey", "orientation": "v", "showlegend": true, "type": "scatter", "x": [34140.643], "xaxis": "x", "y": [104.914], "yaxis": "y"}, {"customdata": [["Uganda"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Uganda", "marker": {"color": "#ab63fa", "size": [213.75900000000001], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Uganda", "orientation": "v", "showlegend": true, "type": "scatter", "x": [887.191], "xaxis": "x", "y": [213.75900000000001], "yaxis": "y"}, {"customdata": [["Ukraine"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Ukraine", "marker": {"color": "#FFA15A", "size": [77.39], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Ukraine", "orientation": "v", "showlegend": true, "type": "scatter", "x": [34526.714], "xaxis": "x", "y": [77.39], "yaxis": "y"}, {"customdata": [["United Arab Emirates"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "United Arab Emirates", "marker": {"color": "#19d3f3", "size": [112.44200000000001], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "United Arab Emirates", "orientation": "v", "showlegend": true, "type": "scatter", "x": [43112.21], "xaxis": "x", "y": [112.44200000000001], "yaxis": "y"}, {"customdata": [["United Kingdom"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "United Kingdom", "marker": {"color": "#FF6692", "size": [272.89799999999997], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "United Kingdom", "orientation": "v", "showlegend": true, "type": "scatter", "x": [62924.753], "xaxis": "x", "y": [272.89799999999997], "yaxis": "y"}, {"customdata": [["United States"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "United States", "marker": {"color": "#B6E880", "size": [35.608000000000004], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "United States", "orientation": "v", "showlegend": true, "type": "scatter", "x": [88938.186], "xaxis": "x", "y": [35.608000000000004], "yaxis": "y"}, {"customdata": [["Uruguay"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Uruguay", "marker": {"color": "#FF97FF", "size": [19.750999999999998], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Uruguay", "orientation": "v", "showlegend": true, "type": "scatter", "x": [20638.064], "xaxis": "x", "y": [19.750999999999998], "yaxis": "y"}, {"customdata": [["Uzbekistan"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Uzbekistan", "marker": {"color": "#FECB52", "size": [76.134], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Uzbekistan", "orientation": "v", "showlegend": true, "type": "scatter", "x": [2407.198], "xaxis": "x", "y": [76.134], "yaxis": "y"}, {"customdata": [["Vanuatu"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Vanuatu", "marker": {"color": "#636efa", "size": [22.662], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Vanuatu", "orientation": "v", "showlegend": true, "type": "scatter", "x": [9.767000000000001], "xaxis": "x", "y": [22.662], "yaxis": "y"}, {"customdata": [["Venezuela"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Venezuela", "marker": {"color": "#EF553B", "size": [36.253], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Venezuela", "orientation": "v", "showlegend": true, "type": "scatter", "x": [5112.508], "xaxis": "x", "y": [36.253], "yaxis": "y"}, {"customdata": [["Vietnam"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Vietnam", "marker": {"color": "#00cc96", "size": [308.127], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Vietnam", "orientation": "v", "showlegend": true, "type": "scatter", "x": [26.238000000000003], "xaxis": "x", "y": [308.127], "yaxis": "y"}, {"customdata": [["Yemen"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Yemen", "marker": {"color": "#ab63fa", "size": [53.508], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Yemen", "orientation": "v", "showlegend": true, "type": "scatter", "x": [95.085], "xaxis": "x", "y": [53.508], "yaxis": "y"}, {"customdata": [["Zambia"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Zambia", "marker": {"color": "#FFA15A", "size": [22.995], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Zambia", "orientation": "v", "showlegend": true, "type": "scatter", "x": [4612.555], "xaxis": "x", "y": [22.995], "yaxis": "y"}, {"customdata": [["Zimbabwe"]], "hovertemplate": "location=%{customdata[0]}<br>total_cases_per_million=%{x}<br>population_density=%{marker.size}<extra></extra>", "legendgroup": "Zimbabwe", "marker": {"color": "#19d3f3", "size": [42.729], "sizemode": "area", "sizeref": 48.36875, "symbol": "circle"}, "mode": "markers", "name": "Zimbabwe", "orientation": "v", "showlegend": true, "type": "scatter", "x": [2454.698], "xaxis": "x", "y": [42.729], "yaxis": "y"}],                        {"legend": {"itemsizing": "constant", "title": {"text": "location"}, "tracegroupgap": 0}, "template": {"data": {"bar": [{"error_x": {"color": "#2a3f5f"}, "error_y": {"color": "#2a3f5f"}, "marker": {"line": {"color": "#E5ECF6", "width": 0.5}}, "type": "bar"}], "barpolar": [{"marker": {"line": {"color": "#E5ECF6", "width": 0.5}}, "type": "barpolar"}], "carpet": [{"aaxis": {"endlinecolor": "#2a3f5f", "gridcolor": "white", "linecolor": "white", "minorgridcolor": "white", "startlinecolor": "#2a3f5f"}, "baxis": {"endlinecolor": "#2a3f5f", "gridcolor": "white", "linecolor": "white", "minorgridcolor": "white", "startlinecolor": "#2a3f5f"}, "type": "carpet"}], "choropleth": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "type": "choropleth"}], "contour": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "contour"}], "contourcarpet": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "type": "contourcarpet"}], "heatmap": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "heatmap"}], "heatmapgl": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "heatmapgl"}], "histogram": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "histogram"}], "histogram2d": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "histogram2d"}], "histogram2dcontour": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "histogram2dcontour"}], "mesh3d": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "type": "mesh3d"}], "parcoords": [{"line": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "parcoords"}], "pie": [{"automargin": true, "type": "pie"}], "scatter": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatter"}], "scatter3d": [{"line": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatter3d"}], "scattercarpet": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scattercarpet"}], "scattergeo": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scattergeo"}], "scattergl": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scattergl"}], "scattermapbox": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scattermapbox"}], "scatterpolar": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatterpolar"}], "scatterpolargl": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatterpolargl"}], "scatterternary": [{"marker": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "type": "scatterternary"}], "surface": [{"colorbar": {"outlinewidth": 0, "ticks": ""}, "colorscale": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "type": "surface"}], "table": [{"cells": {"fill": {"color": "#EBF0F8"}, "line": {"color": "white"}}, "header": {"fill": {"color": "#C8D4E3"}, "line": {"color": "white"}}, "type": "table"}]}, "layout": {"annotationdefaults": {"arrowcolor": "#2a3f5f", "arrowhead": 0, "arrowwidth": 1}, "autotypenumbers": "strict", "coloraxis": {"colorbar": {"outlinewidth": 0, "ticks": ""}}, "colorscale": {"diverging": [[0, "#8e0152"], [0.1, "#c51b7d"], [0.2, "#de77ae"], [0.3, "#f1b6da"], [0.4, "#fde0ef"], [0.5, "#f7f7f7"], [0.6, "#e6f5d0"], [0.7, "#b8e186"], [0.8, "#7fbc41"], [0.9, "#4d9221"], [1, "#276419"]], "sequential": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]], "sequentialminus": [[0.0, "#0d0887"], [0.1111111111111111, "#46039f"], [0.2222222222222222, "#7201a8"], [0.3333333333333333, "#9c179e"], [0.4444444444444444, "#bd3786"], [0.5555555555555556, "#d8576b"], [0.6666666666666666, "#ed7953"], [0.7777777777777778, "#fb9f3a"], [0.8888888888888888, "#fdca26"], [1.0, "#f0f921"]]}, "colorway": ["#636efa", "#EF553B", "#00cc96", "#ab63fa", "#FFA15A", "#19d3f3", "#FF6692", "#B6E880", "#FF97FF", "#FECB52"], "font": {"color": "#2a3f5f"}, "geo": {"bgcolor": "white", "lakecolor": "white", "landcolor": "#E5ECF6", "showlakes": true, "showland": true, "subunitcolor": "white"}, "hoverlabel": {"align": "left"}, "hovermode": "closest", "mapbox": {"style": "light"}, "paper_bgcolor": "white", "plot_bgcolor": "#E5ECF6", "polar": {"angularaxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}, "bgcolor": "#E5ECF6", "radialaxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}}, "scene": {"xaxis": {"backgroundcolor": "#E5ECF6", "gridcolor": "white", "gridwidth": 2, "linecolor": "white", "showbackground": true, "ticks": "", "zerolinecolor": "white"}, "yaxis": {"backgroundcolor": "#E5ECF6", "gridcolor": "white", "gridwidth": 2, "linecolor": "white", "showbackground": true, "ticks": "", "zerolinecolor": "white"}, "zaxis": {"backgroundcolor": "#E5ECF6", "gridcolor": "white", "gridwidth": 2, "linecolor": "white", "showbackground": true, "ticks": "", "zerolinecolor": "white"}}, "shapedefaults": {"line": {"color": "#2a3f5f"}}, "ternary": {"aaxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}, "baxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}, "bgcolor": "#E5ECF6", "caxis": {"gridcolor": "white", "linecolor": "white", "ticks": ""}}, "title": {"x": 0.05}, "xaxis": {"automargin": true, "gridcolor": "white", "linecolor": "white", "ticks": "", "title": {"standoff": 15}, "zerolinecolor": "white", "zerolinewidth": 2}, "yaxis": {"automargin": true, "gridcolor": "white", "linecolor": "white", "ticks": "", "title": {"standoff": 15}, "zerolinecolor": "white", "zerolinewidth": 2}}}, "title": {"text": "Population density vs total_cases_per_million"}, "xaxis": {"anchor": "y", "domain": [0.0, 1.0], "title": {"text": "total_cases_per_million"}}, "yaxis": {"anchor": "x", "domain": [0.0, 1.0], "title": {"text": "population_density"}}},                        {"responsive": true}                    ).then(function(){

var gd = document.getElementById('f3e52e34-25d5-46d3-b76c-4e17ff7c1456');
var x = new MutationObserver(function (mutations, observer) {{
        var display = window.getComputedStyle(gd).display;
        if (!display || display === 'none') {{
            console.log([gd, 'removed!']);
            Plotly.purge(gd);
            observer.disconnect();
        }}
}});

// Listen for the removal of the full notebook cells
var notebookContainer = gd.closest('#notebook-container');
if (notebookContainer) {{
    x.observe(notebookContainer, {childList: true});
}}

// Listen for the clearing of the current output cell
var outputEl = gd.closest('.output');
if (outputEl) {{
    x.observe(outputEl, {childList: true});
}}

                        })                };                });            </script>        </div>


Countries with very small populations tend to have very high total_cases_per_million values, indicating that they may be over-extrapolated. These values may be removed later.

# Modeling 

### One Hot Encoding for the Random Forest (***may not be used, ignore for now)


```python

y=odf2.total_deaths_per_million
X=odf2[odf2.columns.difference(['total_deaths_per_million','total_cases_per_million','date','tests_units','continent'])]

odf2_onehot = odf2.copy()
odf2_onehot = pd.get_dummies(odf2, columns = str_cols, prefix = str_cols)
odf2_onehot
```


```python
str_cols = X.select_dtypes(include="object").columns.to_list()
str_cols

odf_onehot = odf.copy()
odf_onehot = pd.get_dummies(odf, columns=str_cols, prefix = str_cols)
odf_onehot

y=odf_onehot.total_deaths_per_million
X=odf_onehot[odf_onehot.columns.difference(['total_deaths_per_million','total_cases_per_million','date','tests_units','continent'])]
#X_o = X.fillna(X.median())
```

# Random Forest Regressor


```python
y=odf.total_deaths_per_million
#y=odf.total_cases_per_million
#y=odf.reproduction_rate

X=odf[odf.columns.difference(['total_deaths_per_million','total_cases_per_million','date',
                              'tests_units','continent','location','reproduction_rate'])] 
```


```python
train_X, val_X, train_y, val_y = train_test_split(X, y, random_state=1)
```


```python
imp = SimpleImputer(missing_values=np.nan, strategy='median')
imp = imp.fit(train_X)
train_X = imp.transform(train_X)

valimp = SimpleImputer(missing_values=np.nan, strategy='median')
valimp = valimp.fit(val_X)
val_X = valimp.transform(val_X)
##train_y2 = train_y.fillna(train_y.median())
```


```python
clf = RandomForestRegressor(n_estimators=100, bootstrap = True, random_state = 1)
clf = clf.fit(train_X, train_y)
```


```python
print('R^2 training set: {:.2f} \nR^2 val set: {:.2f}'.format(clf.score(train_X, train_y),clf.score(val_X, val_y)))

```

    R^2 training set: 1.00 
    R^2 val set: 0.97
    


```python
val_pred = clf.predict(val_X)
val_mae = mean_absolute_error(val_pred, val_y)
print("Validation MAE: {:,.0f}".format(val_mae))
```

    Validation MAE: 13
    

Extremely high R^2 score and very low MAE suggests severe overfitting of the model 


```python
importances = clf.feature_importances_
std = np.std([tree.feature_importances_ for tree in clf.estimators_],axis=0)
indices = np.argsort(importances)[::-1]

print("Feature ranking:")

for f in range (train_X.shape[1]):
    featurelist = []
    featurelist.append(X.columns[indices[f]])
    print(f + 1,"\t", X.columns[indices[f]], importances[indices[f]])
    
plt.figure()
plt.title("Feature importances")
plt.bar(range(train_X.shape[1]), importances[indices],
        color="r", yerr=std[indices], align="center")
plt.xticks(range(train_X.shape[1]), indices)
plt.xlim([-1, train_X.shape[1]])
plt.show()
```

    Feature ranking:
    1 	 total_tests_per_thousand 0.30238333179499766
    2 	 stringency_index 0.1266759423501055
    3 	 female_smokers 0.0993085604737081
    4 	 median_age 0.057734203689935336
    5 	 cardiovasc_death_rate 0.05572520461657179
    6 	 extreme_poverty 0.04853498263097808
    7 	 positive_rate 0.04468693442499092
    8 	 tests_per_case 0.04082469200895188
    9 	 male_smokers 0.034307003397373574
    10 	 population_density 0.03411444064722002
    11 	 population 0.031872302888283945
    12 	 human_development_index 0.027927872882276456
    13 	 hospital_beds_per_thousand 0.026200063056643633
    14 	 diabetes_prevalence 0.02504891809667056
    15 	 gdp_per_capita 0.021205684936216558
    16 	 life_expectancy 0.01943986932645278
    17 	 handwashing_facilities 0.0040099927786232
    


![png](output_70_1.png)


The model itself is too biased for these feature importances to hold significance.

# SMOGN : Synthetic Minority Over-Sampling Technique for Regression with Gaussian Noise


The imbalanced data SMOGN technique


```python
#!pip install smogn https://pypi.org/project/smogn/#files
```

    Collecting smogn
      Downloading smogn-0.1.2-py3-none-any.whl (30 kB)
    Requirement already satisfied: pandas in c:\users\ramello\anaconda3\lib\site-packages (from smogn) (1.0.1)
    Requirement already satisfied: numpy in c:\users\ramello\anaconda3\lib\site-packages (from smogn) (1.18.1)
    Requirement already satisfied: tqdm in c:\users\ramello\anaconda3\lib\site-packages (from smogn) (4.42.1)
    Requirement already satisfied: pytz>=2017.2 in c:\users\ramello\anaconda3\lib\site-packages (from pandas->smogn) (2019.3)
    Requirement already satisfied: python-dateutil>=2.6.1 in c:\users\ramello\anaconda3\lib\site-packages (from pandas->smogn) (2.8.1)
    Requirement already satisfied: six>=1.5 in c:\users\ramello\anaconda3\lib\site-packages (from python-dateutil>=2.6.1->pandas->smogn) (1.14.0)
    Installing collected packages: smogn
    Successfully installed smogn-0.1.2
    

# Multiple Regression 


```python
model = sm.OLS(train_y, train_X).fit()
```


```python
predictions = model.predict(train_X)
```


```python
model.summary()
```




<table class="simpletable">
<caption>OLS Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>    <td>total_deaths_per_million</td> <th>  R-squared (uncentered):</th>       <td>   0.502</td>  
</tr>
<tr>
  <th>Model:</th>                       <td>OLS</td>           <th>  Adj. R-squared (uncentered):</th>  <td>   0.501</td>  
</tr>
<tr>
  <th>Method:</th>                 <td>Least Squares</td>      <th>  F-statistic:       </th>           <td>   1694.</td>  
</tr>
<tr>
  <th>Date:</th>                 <td>Mon, 08 Mar 2021</td>     <th>  Prob (F-statistic):</th>            <td>  0.00</td>   
</tr>
<tr>
  <th>Time:</th>                     <td>22:19:02</td>         <th>  Log-Likelihood:    </th>          <td>-2.0113e+05</td>
</tr>
<tr>
  <th>No. Observations:</th>          <td> 28642</td>          <th>  AIC:               </th>           <td>4.023e+05</td> 
</tr>
<tr>
  <th>Df Residuals:</th>              <td> 28625</td>          <th>  BIC:               </th>           <td>4.024e+05</td> 
</tr>
<tr>
  <th>Df Model:</th>                  <td>    17</td>          <th>                     </th>               <td> </td>     
</tr>
<tr>
  <th>Covariance Type:</th>          <td>nonrobust</td>        <th>                     </th>               <td> </td>     
</tr>
</table>
<table class="simpletable">
<tr>
   <td></td>      <th>coef</th>     <th>std err</th>      <th>t</th>      <th>P>|t|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>x1</th>  <td>   -0.2815</td> <td>    0.019</td> <td>  -14.998</td> <td> 0.000</td> <td>   -0.318</td> <td>   -0.245</td>
</tr>
<tr>
  <th>x2</th>  <td>   -5.9609</td> <td>    0.620</td> <td>   -9.613</td> <td> 0.000</td> <td>   -7.176</td> <td>   -4.745</td>
</tr>
<tr>
  <th>x3</th>  <td>   -1.1271</td> <td>    0.168</td> <td>   -6.729</td> <td> 0.000</td> <td>   -1.455</td> <td>   -0.799</td>
</tr>
<tr>
  <th>x4</th>  <td>    5.8149</td> <td>    0.267</td> <td>   21.775</td> <td> 0.000</td> <td>    5.291</td> <td>    6.338</td>
</tr>
<tr>
  <th>x5</th>  <td>   -0.0026</td> <td>    0.000</td> <td>  -18.965</td> <td> 0.000</td> <td>   -0.003</td> <td>   -0.002</td>
</tr>
<tr>
  <th>x6</th>  <td>    0.0513</td> <td>    0.117</td> <td>    0.439</td> <td> 0.661</td> <td>   -0.178</td> <td>    0.280</td>
</tr>
<tr>
  <th>x7</th>  <td>  -12.7636</td> <td>    1.024</td> <td>  -12.467</td> <td> 0.000</td> <td>  -14.770</td> <td>  -10.757</td>
</tr>
<tr>
  <th>x8</th>  <td>  302.5648</td> <td>   42.840</td> <td>    7.063</td> <td> 0.000</td> <td>  218.596</td> <td>  386.534</td>
</tr>
<tr>
  <th>x9</th>  <td>   -3.4154</td> <td>    0.422</td> <td>   -8.100</td> <td> 0.000</td> <td>   -4.242</td> <td>   -2.589</td>
</tr>
<tr>
  <th>x10</th> <td>   -2.1206</td> <td>    0.170</td> <td>  -12.508</td> <td> 0.000</td> <td>   -2.453</td> <td>   -1.788</td>
</tr>
<tr>
  <th>x11</th> <td>    8.6764</td> <td>    0.524</td> <td>   16.558</td> <td> 0.000</td> <td>    7.649</td> <td>    9.704</td>
</tr>
<tr>
  <th>x12</th> <td> 3.419e-08</td> <td> 1.17e-08</td> <td>    2.912</td> <td> 0.004</td> <td> 1.12e-08</td> <td> 5.72e-08</td>
</tr>
<tr>
  <th>x13</th> <td>   -0.0151</td> <td>    0.002</td> <td>   -6.541</td> <td> 0.000</td> <td>   -0.020</td> <td>   -0.011</td>
</tr>
<tr>
  <th>x14</th> <td>  907.7020</td> <td>   18.085</td> <td>   50.191</td> <td> 0.000</td> <td>  872.255</td> <td>  943.149</td>
</tr>
<tr>
  <th>x15</th> <td>    0.6867</td> <td>    0.096</td> <td>    7.147</td> <td> 0.000</td> <td>    0.498</td> <td>    0.875</td>
</tr>
<tr>
  <th>x16</th> <td>   -0.0297</td> <td>    0.002</td> <td>  -13.881</td> <td> 0.000</td> <td>   -0.034</td> <td>   -0.026</td>
</tr>
<tr>
  <th>x17</th> <td>    0.2984</td> <td>    0.006</td> <td>   53.010</td> <td> 0.000</td> <td>    0.287</td> <td>    0.309</td>
</tr>
</table>
<table class="simpletable">
<tr>
  <th>Omnibus:</th>       <td>10250.210</td> <th>  Durbin-Watson:     </th> <td>   1.997</td> 
</tr>
<tr>
  <th>Prob(Omnibus):</th>  <td> 0.000</td>   <th>  Jarque-Bera (JB):  </th> <td>41180.748</td>
</tr>
<tr>
  <th>Skew:</th>           <td> 1.756</td>   <th>  Prob(JB):          </th> <td>    0.00</td> 
</tr>
<tr>
  <th>Kurtosis:</th>       <td> 7.709</td>   <th>  Cond. No.          </th> <td>4.00e+09</td> 
</tr>
</table><br/><br/>Warnings:<br/>[1] Standard Errors assume that the covariance matrix of the errors is correctly specified.<br/>[2] The condition number is large,  4e+09. This might indicate that there are<br/>strong multicollinearity or other numerical problems.




```python
print(X.columns[8], X.columns[12], X.columns[14])
```

    life_expectancy population_density stringency_index
    

Pop. Density, Life_expectancy and Stringency_index look like the strongest candidates for feature importance from the linear regression, however these results should be interpreted with caution.

Next steps to fix for the final results;
- bucketize the y output into discrete variables
- try KNN algorithms
- only take the most recent data(time series)
